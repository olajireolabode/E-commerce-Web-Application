<?php
require_once 'models/CommentModel.php';
require_once 'models/ProductModel.php';

// controllers/CommentController.php
class CommentController {
    private $db;
    private $commentModel;
    private $productModel;

    public function __construct($db) {
        $this->db = $db;
        $this->commentModel = new CommentModel($this->db);
        $this->productModel = new ProductModel($this->db);
    }

    public function viewComments() {
        // Retrieve the product ID from the request (you may need to adjust this based on your routing)
        $productId = $_GET['product_id'] ?? null;

        if (!$productId || !$this->productModel->getProductById($productId)) {
            http_response_code(404);
            exit('Product not found.');
        }

        // Get the product and its existing comments.
        $product = $this->productModel->getProductById($productId);
        $comments = $this->commentModel->getCommentsForProduct($productId);

        include 'views/comments/view_comments.php';
    }

    public function addComment() {
        require_login();
        verify_csrf_token();
        $productId = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
        $userName = $_SESSION['user']['user_name'];
        $commentText = trim($_POST['comment'] ?? '');
        if (!$productId || $commentText === '') {
            exit('Invalid comment.');
        }

        // Add the comment to the database
        $success = $this->commentModel->addComment($productId, $userName, $commentText);

        if ($success) {
            // Redirect back to the view comments page
            header("Location: index.php?controller=comment&action=viewComments&product_id=$productId");
            exit;
        } else {
            echo 'Failed to add comment.';
        }
    }
    public function replyToComment() {
        require_admin();
        verify_csrf_token();

        $commentId = filter_input(INPUT_POST, 'comment_id', FILTER_VALIDATE_INT);
        $replyText = trim($_POST['reply'] ?? '');
        $productId = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);

        if (!$commentId || !$productId || $replyText === '') {
            exit('Please provide a valid reply.');
        }

        if (!$this->commentModel->commentExists($commentId)) {
            exit('Comment not found.');
        }

        $adminUsername = $_SESSION['user']['user_name'];
        $this->commentModel->addAdminReply($commentId, $adminUsername, $replyText);

        header("Location: index.php?controller=comment&action=viewComments&product_id=$productId");
        exit;
    }

}

?>
