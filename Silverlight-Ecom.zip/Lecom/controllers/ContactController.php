<?php
require_once 'models/ContactUsModel.php';

class ContactController {
    private $contactUsModel;

    public function __construct($db) {
        $this->contactUsModel = new ContactUsModel($db);
    }

    public function addcontact() {
        require_login();
        verify_csrf_token();
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $message = trim($_POST['message'] ?? '');
        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $message === '') {
            exit('Please provide valid contact information.');
        }
        $this->contactUsModel->addcontact($name, $email, $message);
        header('Location: index.php?controller=home&action=contactUs&sent=1');
        exit;
    }
}
