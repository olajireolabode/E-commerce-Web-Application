<?php
require_once 'models/CartModel.php';

class CartController {
    private $db;
    private $cartModel;

    public function __construct($db) {
        $this->db = $db;
        $this->cartModel = new CartModel($this->db);
    }

    private function requireLogin() {
        if (!isset($_SESSION['user']['user_name'])) {
            header('Location: index.php?controller=user&action=login');
            exit;
        }
        return $_SESSION['user']['user_name'];
    }

    public function deleteItem() {
        $username = $this->requireLogin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { exit('Invalid request.'); }
        verify_csrf_token();
        $pk = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

        if ($pk !== false && $pk !== null) {
            $this->cartModel->deleteItemByID($pk, $username);
        }

        header('Location: index.php?controller=cart&action=viewCart');
        exit;
    }

    public function updateCount() {
        $username = $this->requireLogin();
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['success'=>false,'message'=>'Invalid request.']); return; }
        verify_csrf_token();
        $pk = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        $quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);

        header('Content-Type: application/json');

        if ($pk === false || $pk === null || $quantity === false || $quantity === null) {
            echo json_encode([
                'success' => false,
                'message' => 'Invalid cart item or quantity.'
            ]);
            return;
        }

        echo json_encode($this->cartModel->updateItemByID($pk, $quantity, $username));
    }

    public function viewCart() {
        $username = $this->requireLogin();
        $user_cart = $this->cartModel->get_user_cart($username);
        require 'views/cart.php';
    }

    public function checkout() {
        $username = $this->requireLogin();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (empty($_POST['payment_confirmed'])) {
                $error = 'Please confirm that this is a demo order.';
            } else {
                $result = $this->cartModel->placeOrder($username);
            }

            if (isset($result)) {
                if ($result['success']) {
                    require 'views/order_confirmation.php';
                    return;
                }
                $error = $result['message'];
            }
        }

        $user_cart = $this->cartModel->get_user_cart($username);
        $total_item = 0;
        $total_amount = 0;

        foreach ($user_cart as $cart) {
            $total_item += (int)$cart['quantity'];
            $total_amount += (float)$cart['product_price'] * (int)$cart['quantity'];
        }

        if (empty($user_cart) && !isset($error)) {
            header('Location: index.php?controller=cart&action=viewCart');
            exit;
        }

        require 'views/checkout.php';
    }

    public function addProduct() {
        verify_csrf_token();
        $username = $this->requireLogin();
        $product_id = filter_input(INPUT_POST, 'productId', FILTER_VALIDATE_INT);
        $quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);

        if ($product_id === false || $product_id === null || $quantity === false || $quantity === null || $quantity < 1) {
            header('Location: index.php?controller=home&action=index&error=invalid_product');
            exit;
        }

        $result = $this->cartModel->add_to_cart($product_id, $quantity, $username);

        $suffix = $result['success'] ? 'added=1' : 'error=' . urlencode($result['message']);
        header('Location: index.php?controller=home&action=index&' . $suffix);
        exit;
    }
}
