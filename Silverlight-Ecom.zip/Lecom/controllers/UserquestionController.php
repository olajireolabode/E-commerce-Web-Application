<?php
require_once 'models/UserQuestionModel.php';

class UserquestionController {

    private $db;
    private $userModel;

    public function __construct($db) {
        $this->db = $db;
        //echo "UserController constructed with database connection.";
        $this->userModel = new UserQuestionModel($this->db);

    }    


    public function addquestion() {
        require_login();
        verify_csrf_token();
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $message = trim($_POST['message'] ?? '');
        $username = $_SESSION['user']['user_name'];
        if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $message === '') {
            exit('Please provide valid contact information.');
        }
        // Insert the user into the database
        $this->userModel->insert_user_question($name, $email, $message, $username);

        header('Location: index.php?controller=home&action=contactUs');

        // Other logic...
    }
    public function get_user_question(){
        $username = $_SESSION['user']['user_name'];
        $question_qs = $this->userModel->get_question_answer_by_username($username);

    }
}

?>









