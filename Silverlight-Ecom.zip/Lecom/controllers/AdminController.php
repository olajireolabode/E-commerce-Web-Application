<?php
require_once 'models/UserModel.php';
require_once 'models/UserQuestionModel.php';

class AdminController {
    private $userModel;
    private $userquestionModel;
    private $db;


    public function __construct($db) {
        $this->db = $db;
        // Initialize the UserModel in the constructor
        $this->userModel = new UserModel($db);
        $this->userquestionModel = new UserQuestionModel($db);
        
    }

    public function landingPage() {
        //echo 'Entering landingPage method<br>';

        // Check if the user is logged in
        if ($this->checkIfUserIsLoggedIn()) {
            // Check if the user is an admin
            if ($this->checkIfUserIsAdmin()) {
                // Display the admin landing page
                include 'views/admin/landing_page.php';
            } else {
                // Redirect non-admin users to the home page
                header('Location: index.php?controller=home&action=index');
                exit;
            }
        } else {
            // Redirect not logged in users to the login page
            header('Location: index.php?controller=user&action=login');
            exit;
        }
    }

    private function checkIfUserIsLoggedIn() {
        return isset($_SESSION['user']);
    }

    private function checkIfUserIsAdmin() {
        //echo 'Checking if user is an admin<br>';
        return isset($_SESSION['user']['user_group']) && $_SESSION['user']['user_group'] === 'admin';
    }

    public function dashboard() {
        require_admin();
        try {
            $users = $this->userModel->getAllUsers();
            $stats = [
                'users' => (int)$this->db->query("SELECT COUNT(*) FROM users")->fetchColumn(),
                'admins' => (int)$this->db->query("SELECT COUNT(*) FROM users WHERE user_group = 'admin'")->fetchColumn(),
                'products' => (int)$this->db->query("SELECT COUNT(*) FROM products")->fetchColumn(),
                'orders' => (int)$this->db->query("SELECT COUNT(*) FROM orders")->fetchColumn(),
                'gyms' => (int)$this->db->query("SELECT COUNT(*) FROM gyms")->fetchColumn(),
                'trainers' => (int)$this->db->query("SELECT COUNT(*) FROM trainers")->fetchColumn(),
                'messages' => (int)$this->db->query("SELECT COUNT(*) FROM user_question")->fetchColumn(),
                'low_stock' => (int)$this->db->query("SELECT COUNT(*) FROM products WHERE product_quantity <= 10")->fetchColumn(),
            ];

            $recentOrders = $this->db->query("
                SELECT o.order_id, o.order_date, uo.user_name,
                       COALESCE(SUM(op.quantity * p.product_price), 0) AS total
                FROM orders o
                LEFT JOIN users_orders uo ON uo.order_id = o.order_id
                LEFT JOIN orders_products op ON op.order_id = o.order_id
                LEFT JOIN products p ON p.product_id = op.product_id
                GROUP BY o.order_id, o.order_date, uo.user_name
                ORDER BY o.order_id DESC
                LIMIT 6
            ")->fetchAll(PDO::FETCH_ASSOC);

            include 'views/admin/dashboard.php';
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }
    public function usermessage() {
        require_admin();
        try {
            // Fetch user details from the database
            $user_question = $this->userquestionModel->get_all_user_question();

            // Load the view to display the admin dashboard
            include 'views/admin/usermessage.php';
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }
    public function replymessage() {
        require_admin();
        try {
            $pk = $_GET["pk"];
            $question =  $this->userquestionModel->getQuestionById($pk);
            $answers = $this->userquestionModel->get_user_question_answer($pk);
            include 'views/admin/replymessage.php';
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }
    public function postmessagereply() {
        require_admin();
        verify_csrf_token();
        $pk = $_POST['pk'];
        $message = $_POST['message'];
        $this->userquestionModel->insert_question_answer($pk, $message);
        header('Location: index.php?controller=admin&action=usermessage');

    }
    public function postmessagereplysfromuser() {
        // Kept for backwards compatibility with old links, but normal users
        // are no longer allowed to reply to support messages.
        require_admin();
        verify_csrf_token();
        $pk = filter_input(INPUT_POST, 'qpk', FILTER_VALIDATE_INT);
        $message = trim($_POST['message'] ?? '');
        if (!$pk || $message === '') {
            exit('Invalid reply.');
        }
        $this->userquestionModel->insert_question_answer($pk, $message);
        header('Location: index.php?controller=admin&action=usermessage');
        exit;
    }

    public function promoteUser() {
        verify_csrf_token();
        // Check if the user is logged in and is an admin
        if ($this->checkIfUserIsLoggedIn() && $this->checkIfUserIsAdmin()) {
            // Get the username to be promoted from the form submission
            $username = $_POST['username'];
    
            // Update the user role to 'admin' in the database
            $this->userModel->promoteUserToAdmin($username);
    
            // Redirect back to the admin dashboard
            header('Location: index.php?controller=admin&action=dashboard');
            exit;
        } else {
            // Redirect to the login page if not logged in or not an admin
            header('Location: index.php?controller=user&action=login');
            exit;
        }
    }
}

?>
