<?php
require_once __DIR__ . '/../models/ProductModel.php';

class ProductController {
    private $db;
    private $productModel;

    public function __construct($db) {
        $this->db = $db;
        $this->productModel = new ProductModel($this->db);
    }

    public function insertForm() {
        require_admin();
        require __DIR__ . '/../views/insert_product.php';
    }

    public function insert() {
        require_admin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            verify_csrf_token();
            $productName = trim($_POST['productName'] ?? '');
            $productDescription = trim($_POST['productDescription'] ?? '');
            $productPrice = filter_var($_POST['productPrice'] ?? null, FILTER_VALIDATE_FLOAT);
            $productQuantity = filter_var($_POST['productQuantity'] ?? null, FILTER_VALIDATE_INT);
            if ($productName === '' || $productDescription === '' || $productPrice === false || $productPrice < 0 || $productQuantity === false || $productQuantity < 0) {
                exit('Please provide valid product details.');
            }

            if (!isset($_FILES['productImage']) || $_FILES['productImage']['error'] !== UPLOAD_ERR_OK) {
                exit('Please upload a valid product image.');
            }
            if ($_FILES['productImage']['size'] > 2 * 1024 * 1024) {
                exit('Product images must be 2 MB or smaller.');
            }
            $allowedTypes = [
                'image/jpeg' => 'jpg',
                'image/png' => 'png',
                'image/gif' => 'gif',
                'image/webp' => 'webp'
            ];
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES['productImage']['tmp_name']);
            if (!isset($allowedTypes[$mime])) {
                exit('Only JPG, PNG, GIF, and WEBP images are allowed.');
            }
            $uploadDirectory = __DIR__ . '/../images/products/';
            if (!is_dir($uploadDirectory)) {
                mkdir($uploadDirectory, 0755, true);
            }
            $targetFile = 'products/' . bin2hex(random_bytes(12)) . '.' . $allowedTypes[$mime];
            if (!move_uploaded_file($_FILES['productImage']['tmp_name'], $uploadDirectory . basename($targetFile))) {
                exit('Unable to save the product image.');
            }

            // Insert into the database
            $this->productModel->insertProduct($productName, $productDescription, $targetFile, $productPrice, $productQuantity);

            // Redirect to the homepage
            header('Location: index.php?controller=home&action=index');
            exit;
        } else {
            echo 'Invalid request.';
        }
    }

    public function viewProduct() {
        $productId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

        if (!$productId) {
            header('Location: index.php?controller=home&action=index#shop');
            exit;
        }

        $product = $this->productModel->getProductById($productId);

        if (!$product) {
            http_response_code(404);
            include __DIR__ . '/../views/404.html';
            exit;
        }

        include __DIR__ . '/../views/product_detail.php';
    }

    public function displayDetails() {
        require_admin();
        try {
            // Fetch product details from the database
            $products = $this->getProducts();

            // Load the view to display product details
            include __DIR__ . '/../views/admin/display_products.php';
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }

    // Method to fetch product details from the database
    private function getProducts() {
        $query = 'SELECT * FROM products';
        $stmt = $this->db->prepare($query);
        $stmt->execute();

        // Fetch all products
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getProductById($productId) {
        $query = 'SELECT * FROM products WHERE product_id = :product_id';
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
        $stmt->execute();
    
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function editProductForm() {
        require_admin();
        if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
            $productId = $_GET['id'];
            $existingProduct = $this->productModel->getProductById($productId);

            if ($existingProduct) {
                include __DIR__ . '/../views/admin/edit_product.php';
            } else {
                // Handle product not found
                echo 'Product not found.';
            }
        } else {
            // Handle invalid request
            echo 'Invalid request.';
        }
    }

    public function updateProduct() {
        require_admin();
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_product'])) {
            verify_csrf_token();
            $productId = $_POST['product_id'];
            $productName = $_POST['product_name'];
            $productDescription = $_POST['product_description'];
            $productPrice = $_POST['product_price'];
            $productQuantity = $_POST['product_quantity'];

            // Update the product in the database
            $success = $this->productModel->updateProduct($productId, $productName, $productDescription, $productPrice, $productQuantity);

            if ($success) {
                // Redirect to the product details page or dashboard
                header('Location: index.php?controller=product&action=displayDetails');
                exit;
            } else {
                // Handle update failure
                echo 'Update failed.';
            }
        } else {
            // Handle invalid request
            echo 'Invalid request.';
        }
    }

    public function deleteProduct() {
        require_admin();
        // Deletions are POST-only to avoid accidental destructive requests.
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
            verify_csrf_token();
            $productId = (int)$_POST['id'];
    
            // Delete the product from the database
            $success = $this->productModel->deleteProduct($productId);
    
            if ($success) {
                // Redirect to the product details page or dashboard
                header('Location: index.php?controller=product&action=displayDetails');
                exit;
            } else {
                // Handle delete failure
                echo 'Delete failed.';
            }
        } else {
            // Handle invalid request
            echo 'Invalid request.';
        }
    }
}
?>
