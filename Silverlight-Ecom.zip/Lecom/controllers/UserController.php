<?php
require_once 'models/UserModel.php';

class UserController {

    private $db;

    public function __construct($db) {
        $this->db = $db;
        //echo "UserController constructed with database connection.";

    }    
    
    public function login() {
        require 'views/login.php';
    }


    public function authenticate() {
        // ... (existing authentication logic)
            // Get user input
        verify_csrf_token();
        $usernameOrEmail = trim($_POST['usernameOrEmail'] ?? '');
        $password = $_POST['password'] ?? '';
        if ($usernameOrEmail === '' || $password === '') {
            header('Location: index.php?controller=user&action=login&error=Please%20enter%20your%20username%20and%20password');
            exit;
        }

        // Authenticate user
        $userModel = new UserModel($this->db);
        $user = $userModel->getUserByUsernameOrEmail($usernameOrEmail);

        if ($user && password_verify($password, $user['password'])) {
            // Authentication successful. Rotate the session ID to prevent session fixation.
            session_regenerate_id(true);
            $_SESSION['user'] = $user;

            // Redirect to the admin landing page
            if ($user['user_group'] === 'admin') {
                header('Location: index.php?controller=admin&action=landingPage');
            } else {
                header('Location: index.php?controller=home&action=index');
            }

            exit;
        } else {
            // Authentication failed
           header('Location: index.php?controller=user&action=login&error=' . urlencode('Username and/or password is invalid.'));
            exit;
        }
    }

    public function registerForm() {
        // Check if the user is an admin (you need to implement this logic)
        //$isAdmin = $this->checkIfUserIsAdmin();

        // Load the register view, passing the $isAdmin variable
        require 'views/register.php';
    }

    public function register() {
        // Other registration logic...

        // Get user input
        verify_csrf_token();
        $username = trim($_POST['username'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $rawPassword = $_POST['password'] ?? '';
        $confirmPassword = $_POST['confirmPassword'] ?? '';

        $errors = [];

        if ($username === '') {
            $errors[] = 'Username is required.';
        } elseif (strlen($username) < 3) {
            $errors[] = 'Username must be at least 3 characters.';
        }

        if ($email === '') {
            $errors[] = 'Email is required.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        }

        if ($rawPassword === '') {
            $errors[] = 'Password is required.';
        } elseif (strlen($rawPassword) < 8) {
            $errors[] = 'Password must be at least 8 characters.';
        }

        if ($confirmPassword === '') {
            $errors[] = 'Please confirm your password.';
        } elseif ($rawPassword !== $confirmPassword) {
            $errors[] = 'Passwords do not match.';
        }

        if (!empty($errors)) {
            $message = implode(' ', $errors);
            header('Location: index.php?controller=user&action=registerForm&error=' . urlencode($message));
            exit;
        }

        $password = password_hash($rawPassword, PASSWORD_DEFAULT);
        // Public registration can never create an administrator.
        $role = 'user';

        // Insert the user into the database
        $userModel = new UserModel($this->db);
        try {
            $userModel->insertUser($username, $email, $password, $role);
        } catch (PDOException $e) {
            if ((int)$e->errorInfo[1] === 1062) {
                header('Location: index.php?controller=user&action=registerForm&error=Username%20or%20email%20already%20exists');
                exit;
            }
            throw $e;
        }

        header('Location: index.php?controller=user&action=login');

        // Other logic...
    }

}

?>









