<?php
session_start();

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

// Unset all session variables
$_SESSION = array();

// Destroy the session
session_destroy();

// Prevent the old authenticated page from being restored from browser history.
header('Clear-Site-Data: "cache"');

// Redirect to the login or home page
header("Location: index.php");
exit;
?>
