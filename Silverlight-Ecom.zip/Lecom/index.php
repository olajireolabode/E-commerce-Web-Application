<?php
session_start();

// Prevent authenticated pages from being restored from the browser cache after logout.
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function csrf_token() {
    return $_SESSION['csrf_token'];
}

function verify_csrf_token() {
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        exit('Invalid security token. Please go back and try again.');
    }
}

function require_login() {
    if (!isset($_SESSION['user']['user_name'])) {
        header('Location: index.php?controller=user&action=login');
        exit;
    }
}

function require_admin() {
    if (!isset($_SESSION['user']['user_group']) || $_SESSION['user']['user_group'] !== 'admin') {
        header('Location: index.php?controller=home&action=index');
        exit;
    }
}

// Connect using environment variables in production, with XAMPP-friendly defaults locally.
require __DIR__ . '/config/database.php';


// Load the appropriate controller and action based on the URL

$controllerName = $_GET['controller'] ?? 'home';
$action = $_GET['action'] ?? 'index';

$controllerClassName = ucfirst($controllerName) . 'Controller';
$controllerFile = 'controllers/' . $controllerClassName . '.php';

if (file_exists($controllerFile)) {
    require $controllerFile;

    // Check if the user is logged in
    if (isset($_SESSION['user'])) {
        $user = $_SESSION['user'];
        
        // Check the user's group for routing
        // if ($user['user_group'] === 'admin' && $controllerName !== 'admin') {
        //     header('Location: index.php?controller=admin&action=landingPage');
        //     exit;
        // }
    }

    $controller = new $controllerClassName($db);

    if (method_exists($controller, $action)) {
        $controller->$action();
    } else {
        echo 'Action not found.';
    }
} else {
    echo 'Controller not found.';
}
?>
