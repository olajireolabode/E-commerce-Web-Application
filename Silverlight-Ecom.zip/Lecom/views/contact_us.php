<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Silverlight | Contact</title>
    <link rel="stylesheet" href="css/silverlight.css">
    <link rel="stylesheet" href="css/Contact-Silverlight.css">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>
<main class="page-shell contact-page">
    <header class="contact-hero">
        <div class="section-kicker">We are listening</div>
        <h1>Let's <span>talk.</span></h1>
        <p>Have a question about Silverlight, our products, gyms or trainers? Send us a message and keep the conversation in one place.</p>
    </header>
    <div class="contact-layout">
        <section class="contact-form-card">
            <h2 class="contact-card-title">Send a message</h2>
            <p class="contact-card-subtitle">Your message will be sent to the Silverlight team.</p>
            <?php if (isset($_SESSION['user']['user_name'])): ?>
                <form class="contact-form" action="index.php?controller=userquestion&action=addquestion" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
                    <div class="contact-field"><label for="name">Name</label><input id="name" type="text" name="name" value="<?php echo htmlspecialchars($_SESSION['user']['user_name'], ENT_QUOTES, 'UTF-8'); ?>" required></div>
                    <div class="contact-field"><label for="email">Email</label><input id="email" type="email" name="email" placeholder="you@example.com" required></div>
                    <div class="contact-field"><label for="message">Message</label><textarea id="message" name="message" placeholder="How can we help?" required></textarea></div>
                    <button class="sl-btn contact-submit" type="submit">Send message →</button>
                </form>
            <?php else: ?>
                <div class="contact-login-note">Please <a href="index.php?controller=user&action=login">log in</a> to send a message and view your conversation history.</div>
            <?php endif; ?>
        </section>
        <section class="contact-history-card">
            <div class="section-kicker">Your conversation</div>
            <h2 class="contact-card-title">Message history</h2>
            <p class="contact-card-subtitle">Questions and replies from the Silverlight team appear here.</p>
            <?php if (!empty($user_question)): ?>
                <div class="question-list">
                    <?php foreach ($user_question as $question): ?>
                        <article class="question-card">
                            <div class="question-summary"><span class="question-name"><?php echo htmlspecialchars($question['name'], ENT_QUOTES, 'UTF-8'); ?></span><span class="question-date">Question #<?php echo (int)$question['pk']; ?></span></div>
                            <div class="question-message"><?php echo nl2br(htmlspecialchars($question['message'], ENT_QUOTES, 'UTF-8')); ?></div>
                            <?php if (!empty($question['question_ans'])): ?>
                                <?php foreach ($question['question_ans'] as $answer): ?>
                                    <div class="reply"><strong><?php echo empty($answer['sender']) ? 'Silverlight team' : 'You'; ?></strong><?php echo nl2br(htmlspecialchars($answer['message'], ENT_QUOTES, 'UTF-8')); ?></div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="reply"><strong>Awaiting reply</strong>Our team has not replied yet.</div>
                            <?php endif; ?>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php elseif (isset($_SESSION['user']['user_name'])): ?>
                <div class="no-questions">You have not sent any questions yet.</div>
            <?php else: ?>
                <div class="no-questions">Log in to see your message history.</div>
            <?php endif; ?>
        </section>
    </div>
</main>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
