<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Order Confirmed | Silverlight</title>
    <link rel="stylesheet" href="css/silverlight.css">
    <link rel="stylesheet" href="css/Checkout.css">
    <style>
        .confirmation{max-width:780px;margin:70px auto;padding:42px;text-align:center}.confirmation-mark{width:64px;height:64px;margin:0 auto 22px;border-radius:50%;display:grid;place-items:center;background:rgba(55,214,122,.10);border:1px solid rgba(55,214,122,.35);color:#37d67a;font-size:28px}.confirmation h1{font-family:'Barlow Condensed',sans-serif;font-size:56px;line-height:.9;text-transform:uppercase;margin:0 0 12px}.confirmation-lead{color:#9da4a8;font-size:14px;margin:0 0 7px}.confirmation-order{color:#fff;font-size:13px;margin-bottom:30px}.confirmation-order strong{color:#ff6b63}.confirmation-items{text-align:left;border-top:1px solid var(--sl-border);border-bottom:1px solid var(--sl-border);padding:18px 0;margin-bottom:28px}.confirmation-row{display:flex;justify-content:space-between;gap:20px;padding:8px 0;color:#c5cbce;font-size:13px}.confirmation-row strong{color:#fff}.confirmation-total{display:flex;justify-content:space-between;padding-top:14px;margin-top:8px;border-top:1px solid var(--sl-border);font-weight:800;color:#fff}.confirmation-total strong{font-family:'Barlow Condensed',sans-serif;font-size:27px}.confirmation-actions{display:flex;justify-content:center;gap:12px;flex-wrap:wrap}.confirmation-secondary{display:inline-flex;align-items:center;justify-content:center;padding:12px 18px;border:1px solid var(--sl-border);border-radius:7px;color:#d3d7d9!important;text-decoration:none!important;font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.06em}.confirmation-secondary:hover{border-color:#fff;color:#fff!important}@media(max-width:600px){.confirmation{margin:35px auto;padding:25px 18px}.confirmation h1{font-size:44px}}
    </style>
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>
<main class="page-shell">
    <section class="confirmation sl-card">
        <div class="confirmation-mark">✓</div>
        <div class="section-kicker">Order complete</div>
        <h1>You're locked in.</h1>
        <p class="confirmation-lead">Your Silverlight demo order has been recorded successfully.</p>
        <p class="confirmation-order">Order number <strong>#<?php echo (int)$result['order_id']; ?></strong></p>
        <div class="confirmation-items">
            <?php foreach ($result['items'] as $item): ?>
                <div class="confirmation-row">
                    <span><?php echo htmlspecialchars($item['product_name'], ENT_QUOTES, 'UTF-8'); ?> × <?php echo (int)$item['quantity']; ?></span>
                    <strong>$<?php echo number_format((float)$item['product_price'] * (int)$item['quantity'], 2); ?></strong>
                </div>
            <?php endforeach; ?>
            <div class="confirmation-total"><span>Total</span><strong>$<?php echo number_format((float)$result['total'], 2); ?></strong></div>
        </div>
        <div class="confirmation-actions">
            <a class="sl-btn" href="index.php?controller=home&action=index">Continue shopping →</a>
            <a class="confirmation-secondary" href="index.php?controller=cart&action=viewCart">View cart</a>
        </div>
    </section>
</main>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
