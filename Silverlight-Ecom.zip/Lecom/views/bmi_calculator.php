<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Silverlight | BMI Calculator</title>
    <link rel="stylesheet" href="css/silverlight.css">
    <link rel="stylesheet" href="css/BMI-Silverlight.css">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>
<main class="page-shell bmi-page">
    <section class="bmi-hero">
        <div class="bmi-copy">
            <div class="section-kicker">Know your numbers</div>
            <h1>Check your <span>BMI.</span></h1>
            <p>Use your height and weight to calculate your Body Mass Index. Silverlight makes the calculation quick and easy so you can use it as one simple data point when thinking about your fitness goals.</p>
            <div class="bmi-note"><strong>01</strong><span>BMI is a screening measure, not a diagnosis. It does not account for muscle mass, body composition or every individual health factor.</span></div>
        </div>
        <div class="bmi-card">
            <h2>BMI Calculator</h2>
            <p>Enter your measurements below.</p>
            <form class="bmi-form" method="POST" action="index.php?controller=home&action=calculateBMI">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
                <div class="bmi-field"><label for="height">Height (cm)</label><input id="height" type="number" name="height" min="1" step="0.1" placeholder="e.g. 170" required></div>
                <div class="bmi-field"><label for="weight">Weight (kg)</label><input id="weight" type="number" name="weight" min="1" step="0.1" placeholder="e.g. 65" required></div>
                <button class="sl-btn bmi-submit" type="submit">Calculate BMI →</button>
            </form>
            <?php if (isset($_SESSION['bmiError'])): ?>
                <div class="bmi-alert" role="alert"><?php echo htmlspecialchars($_SESSION['bmiError'], ENT_QUOTES, 'UTF-8'); ?></div>
                <?php unset($_SESSION['bmiError']); ?>
            <?php endif; ?>
            <?php if (isset($_SESSION['bmiResult'])): ?>
                <?php $bmiValue = (float)$_SESSION['bmiResult']; ?>
                <div class="bmi-result" aria-live="polite">
                    <div class="bmi-result-label">Your result</div>
                    <div class="bmi-number"><?php echo htmlspecialchars((string)$bmiValue, ENT_QUOTES, 'UTF-8'); ?></div>
                    <p><?php echo htmlspecialchars($_SESSION['recommendations'] ?? '', ENT_QUOTES, 'UTF-8'); ?></p>
                </div>
                <?php unset($_SESSION['bmiResult'], $_SESSION['recommendations']); ?>
            <?php endif; ?>
        </div>
    </section>
    <section class="bmi-card">
        <div class="section-kicker">Reference range</div>
        <h2 style="margin-top:6px">BMI categories</h2>
        <div class="bmi-scale" aria-hidden="true"><span></span><span></span><span></span><span></span></div>
        <div class="bmi-scale-labels"><span>Under 18.5</span><span>18.5–24.9</span><span>25–29.9</span><span>30+</span></div>
        <p class="bmi-disclaimer">These ranges are general adult screening categories. For personal health advice or concerns about your weight, speak with a qualified healthcare professional.</p>
    </section>
</main>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
