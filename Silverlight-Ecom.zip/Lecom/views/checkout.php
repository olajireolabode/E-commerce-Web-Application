<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Checkout | Silverlight</title>
    <link rel="stylesheet" href="css/silverlight.css">
    <link rel="stylesheet" href="css/Checkout.css">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>

<main class="checkout-page page-shell">
    <header class="checkout-hero">
        <div class="checkout-hero-copy">
            <div class="section-kicker">Secure demo checkout</div>
            <h1 class="checkout-title">Finish your order.</h1>
            <p class="checkout-subtitle">One final step. Review your order, confirm the demo purchase, and we'll update your inventory and order history.</p>
        </div>
        <div class="checkout-secure">🔒 No real payment is processed</div>
    </header>

    <?php if (!empty($error)): ?>
        <div class="checkout-alert" role="alert">⚠ <?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
    <?php endif; ?>

    <div class="checkout-layout">
        <section class="checkout-card sl-card">
            <form method="post" action="index.php?controller=cart&action=checkout" novalidate>
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">

                <div class="checkout-section">
                    <div class="section-kicker">01 / Details</div>
                    <h2>Customer information</h2>
                    <div class="checkout-grid">
                        <div class="checkout-field">
                            <label for="firstName">First name</label>
                            <input id="firstName" name="first_name" type="text" autocomplete="given-name" placeholder="Esther" required>
                        </div>
                        <div class="checkout-field">
                            <label for="lastName">Last name</label>
                            <input id="lastName" name="last_name" type="text" autocomplete="family-name" placeholder="Doe" required>
                        </div>
                        <div class="checkout-field full">
                            <label for="email">Email</label>
                            <input id="email" name="email" type="email" autocomplete="email" placeholder="you@example.com" required>
                        </div>
                    </div>
                </div>

                <div class="checkout-section">
                    <div class="section-kicker">02 / Delivery</div>
                    <h2>Shipping information</h2>
                    <p class="checkout-help" style="margin-bottom:16px">This information is for the portfolio demo and is not stored with the order.</p>
                    <div class="checkout-grid">
                        <div class="checkout-field full">
                            <label for="address">Address</label>
                            <input id="address" name="address" type="text" autocomplete="street-address" placeholder="123 Main Street" required>
                        </div>
                        <div class="checkout-field">
                            <label for="city">City</label>
                            <input id="city" name="city" type="text" autocomplete="address-level2" placeholder="Montreal" required>
                        </div>
                        <div class="checkout-field">
                            <label for="province">Province / State</label>
                            <input id="province" name="province" type="text" autocomplete="address-level1" placeholder="Quebec" required>
                        </div>
                        <div class="checkout-field">
                            <label for="postal">Postal / ZIP code</label>
                            <input id="postal" name="postal_code" type="text" autocomplete="postal-code" placeholder="H1H 1H1" required>
                        </div>
                        <div class="checkout-field">
                            <label for="country">Country</label>
                            <select id="country" name="country" autocomplete="country-name" required>
                                <option value="">Select country</option>
                                <option>Canada</option>
                                <option>United States</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="checkout-section">
                    <div class="section-kicker">03 / Payment</div>
                    <h2>Demo payment</h2>
                    <div class="checkout-demo"><strong>Portfolio demo:</strong> no credit-card information is collected and no real payment is processed. Placing the order records the purchase and updates product inventory.</div>
                    <label class="checkout-confirm">
                        <input name="payment_confirmed" type="checkbox" value="1" required>
                        <span>I understand that this is a demonstration order and no real payment will be charged.</span>
                    </label>
                </div>

                <button class="sl-btn checkout-submit" type="submit">Place demo order →</button>
                <a class="checkout-back" href="index.php?controller=cart&action=viewCart">← Return to cart</a>
            </form>
        </section>

        <aside class="checkout-summary sl-card">
            <div class="checkout-summary-head">
                <div>
                    <div class="section-kicker">Your selection</div>
                    <h2>Order summary</h2>
                </div>
                <span class="checkout-count"><?php echo (int)$total_item; ?> item<?php echo (int)$total_item === 1 ? '' : 's'; ?></span>
            </div>

            <div class="checkout-items">
                <?php foreach ($user_cart as $cart_item): ?>
                    <?php $line_total = (float)$cart_item['product_price'] * (int)$cart_item['quantity']; ?>
                    <div class="checkout-item">
                        <div class="checkout-item-image">
                            <img src="images/<?php echo htmlspecialchars($cart_item['product_image'], ENT_QUOTES, 'UTF-8'); ?>" alt="">
                        </div>
                        <div>
                            <p class="checkout-item-name"><?php echo htmlspecialchars($cart_item['product_name'], ENT_QUOTES, 'UTF-8'); ?></p>
                            <p class="checkout-item-meta">Qty <?php echo (int)$cart_item['quantity']; ?> · $<?php echo number_format((float)$cart_item['product_price'], 2); ?> each</p>
                        </div>
                        <strong class="checkout-item-price">$<?php echo number_format($line_total, 2); ?></strong>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="checkout-divider"></div>
            <div class="checkout-total">
                <span>Total</span>
                <strong>$<?php echo number_format((float)$total_amount, 2); ?></strong>
            </div>
            <p class="checkout-note">Taxes, shipping, and real payment processing are intentionally omitted from this portfolio demonstration.</p>
        </aside>
    </div>
</main>

<?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
