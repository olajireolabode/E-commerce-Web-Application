<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product &bull; Silverlight Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;800;900&family=Inter:wght@400;600;700;800&display=swap">
    <link rel="stylesheet" href="css/silverlight.css">
    <link rel="stylesheet" href="css/admin-silverlight.css">
</head>
<body class="admin-page">
    <?php include __DIR__ . '/admin/partials/nav.php'; ?>

    <main class="admin-main">
        <div class="admin-form-shell">
            <div class="admin-breadcrumb">
                <a href="index.php?controller=product&action=displayDetails">Products</a>
                <span>/</span>
                <span>Add product</span>
            </div>

            <div class="admin-heading">
                <div>
                    <p class="admin-kicker">Store management</p>
                    <h1>Add <span>product.</span></h1>
                </div>
                <p>Create a new item for the Silverlight storefront. Images should be JPG, PNG, GIF or WEBP and no larger than 2 MB.</p>
            </div>

            <section class="admin-form-card">
                <form action="index.php?controller=product&action=insert" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">

                    <div class="admin-form-grid">
                        <div class="admin-field">
                            <label for="productName">Product name</label>
                            <input id="productName" type="text" name="productName" maxlength="150" required>
                        </div>

                        <div class="admin-field">
                            <label for="productPrice">Price</label>
                            <input id="productPrice" type="number" name="productPrice" min="0" step="0.01" required>
                        </div>

                        <div class="admin-field">
                            <label for="productQuantity">Inventory quantity</label>
                            <input id="productQuantity" type="number" name="productQuantity" min="0" step="1" required>
                        </div>

                        <div class="admin-field">
                            <label for="productImage">Product image</label>
                            <input id="productImage" type="file" name="productImage" accept="image/jpeg,image/png,image/gif,image/webp" required>
                        </div>

                        <div class="admin-field full">
                            <label for="productDescription">Description</label>
                            <textarea id="productDescription" name="productDescription" maxlength="2000" required></textarea>
                            <p class="admin-help">Write a concise product description customers can understand quickly.</p>
                        </div>
                    </div>

                    <div class="admin-form-actions">
                        <button class="admin-btn" type="submit">Create product &rarr;</button>
                        <a class="admin-btn secondary" href="index.php?controller=product&action=displayDetails">Cancel</a>
                    </div>
                </form>
            </section>
        </div>
    </main>

    <footer class="admin-footer">Silverlight Admin &bull; Product catalog</footer>
</body>
</html>
