<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Silverlight | Fitness & Performance</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/silverlight.css">
    <style>
        .sl-home-hero{min-height:520px;display:flex;align-items:center;background:linear-gradient(90deg,rgba(5,7,8,.98) 0%,rgba(5,7,8,.78) 48%,rgba(5,7,8,.15) 100%),url('images/main.jpg') center/cover;border-bottom:1px solid var(--sl-border)}
        .sl-hero-content{width:min(1180px,calc(100% - 40px));margin:0 auto;padding:70px 0}
        .sl-hero-kicker{color:var(--sl-red);font-weight:800;letter-spacing:.18em;text-transform:uppercase;font-size:12px}
        .sl-hero-title{font-family:'Barlow Condensed',sans-serif;font-size:clamp(64px,8vw,112px);line-height:.78;text-transform:uppercase;max-width:650px;margin:16px 0 25px;font-weight:800}
        .sl-hero-title span{color:var(--sl-red)}
        .sl-hero-copy{max-width:520px;color:#b8bec1;line-height:1.7;font-size:15px}
        .sl-hero-actions{display:flex;gap:12px;margin-top:28px;flex-wrap:wrap}
        .sl-ghost-btn{display:inline-flex;align-items:center;padding:12px 18px;border:1px solid rgba(255,255,255,.18);border-radius:7px;text-decoration:none;color:#fff;font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.06em}
        .sl-ghost-btn:hover{background:rgba(255,255,255,.06);color:#fff}
        .sl-feature-strip{display:grid;grid-template-columns:repeat(3,1fr);border:1px solid var(--sl-border);background:#0e1113}
        .sl-feature{padding:22px 24px;border-right:1px solid var(--sl-border)} .sl-feature:last-child{border-right:0}.sl-feature strong{display:block;font-family:'Barlow Condensed';text-transform:uppercase;font-size:18px}.sl-feature span{color:var(--sl-muted);font-size:12px}
        .sl-shop{padding:70px 0}.sl-section-head{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;margin-bottom:24px}.sl-section-head p{margin:0;color:var(--sl-muted);font-size:12px}.sl-sort{display:flex;align-items:center;gap:8px}.sl-sort label{font-size:11px;color:var(--sl-muted);text-transform:uppercase}.sl-sort select{width:165px;padding:9px 10px}
        .sl-empty-search{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;gap:8px;min-height:220px;padding:35px;border:1px dashed var(--sl-border);border-radius:12px;background:#0e1113;color:var(--sl-muted);margin-bottom:18px}.sl-empty-search strong{font-family:'Barlow Condensed';font-size:28px;text-transform:uppercase;color:#fff}.sl-empty-search span{font-size:12px;margin-bottom:8px}.sl-products{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:18px;align-items:stretch}.sl-product{background:linear-gradient(145deg,#151a1d,#0e1113);border:1px solid var(--sl-border);border-radius:11px;overflow:hidden;transition:.22s;position:relative;display:flex;flex-direction:column;height:100%;min-width:0}.sl-product:hover{transform:translateY(-4px);border-color:rgba(255,59,48,.38);box-shadow:var(--sl-shadow)}.sl-product-img{height:230px;flex:0 0 230px;background:#0a0c0d;display:grid;place-items:center;padding:18px;overflow:hidden}.sl-product-img img{width:100%;height:100%;object-fit:contain;display:block}.sl-product-body{padding:16px;display:flex;flex-direction:column;flex:1}.sl-product h2{font-family:'Barlow Condensed';font-size:21px;line-height:1.05;text-transform:uppercase;margin:0 0 8px;min-height:44px;display:flex;align-items:flex-start}.sl-product-desc{color:#858d91;font-size:11px;line-height:1.5;min-height:50px;max-height:50px;overflow:hidden}.sl-product-meta{display:flex;justify-content:space-between;align-items:center;margin:14px 0;min-height:24px}.sl-price{font-size:18px;font-weight:800;color:#fff}.sl-stock{font-size:10px;color:var(--sl-green);text-align:right}.sl-product-form{display:flex;gap:7px;margin-top:auto}.sl-product-form input{width:58px!important;padding:9px!important}.sl-product-form .sl-btn{flex:1;padding:9px 10px;white-space:nowrap}.sl-product-detail{display:block;text-align:center;margin-top:10px;font-size:11px;color:#fff;text-decoration:none;font-weight:800;text-transform:uppercase;letter-spacing:.05em}.sl-product-detail:hover{color:var(--sl-red);text-decoration:none}.sl-comments{display:block;text-align:center;margin-top:7px;font-size:10px;color:#92999c;text-decoration:none}.sl-comments:hover{color:#fff}
        .sl-service-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px;padding-bottom:70px}.sl-service-card{background:var(--sl-surface);border:1px solid var(--sl-border);border-radius:12px;overflow:hidden;position:relative;transition:.22s;box-shadow:var(--sl-shadow)}.sl-service-card:hover{transform:translateY(-4px);border-color:rgba(255,59,48,.38)}.sl-service-image{height:240px;background:#0a0c0d;overflow:hidden;position:relative}.sl-service-image img{width:100%;height:100%;object-fit:cover;display:block;transition:transform .35s ease}.sl-service-card:hover .sl-service-image img{transform:scale(1.03)}.sl-service-image:after{content:'';position:absolute;inset:0;background:linear-gradient(180deg,rgba(5,7,8,.05),rgba(5,7,8,.55))}.sl-service-content{padding:22px 24px 24px;background:linear-gradient(145deg,#14181a,#0e1113)}.sl-service-card h3{font-family:'Barlow Condensed';font-size:34px;line-height:1;text-transform:uppercase;margin:6px 0 8px;color:#fff}.sl-service-card p{color:#aeb5b8;font-size:12px;line-height:1.6;margin:0 0 18px}.sl-service-card a{width:max-content}
        @media(max-width:900px){.sl-products{grid-template-columns:repeat(2,1fr)}.sl-feature-strip{grid-template-columns:1fr}.sl-feature{border-right:0;border-bottom:1px solid var(--sl-border)}.sl-feature:last-child{border-bottom:0}}
        @media(max-width:600px){.sl-service-image{height:200px}.sl-home-hero{min-height:560px}.sl-hero-title{font-size:68px}.sl-products{grid-template-columns:1fr}.sl-service-grid{grid-template-columns:1fr}.sl-section-head{align-items:flex-start;flex-direction:column}}
    </style>
</head>
<body>
    <?php include __DIR__ . '/partials/navbar.php'; ?>

    <main>
        <section class="sl-home-hero">
            <div class="sl-hero-content">
                <div class="sl-hero-kicker">Performance starts here</div>
                <h1 class="sl-hero-title">Stronger.<br>Healthier.<br><span>Brighter.</span></h1>
                <p class="sl-hero-copy">Premium fitness products, trusted trainers and supportive community resources built to help you keep moving toward your goals.</p>
                <div class="sl-hero-actions">
                    <a class="sl-btn" href="#shop">Shop now →</a>
                    <a class="sl-ghost-btn" href="index.php?controller=home&action=otherServices#trainers">Meet our trainers</a>
                </div>
            </div>
        </section>

        <div class="page-shell">
            <section class="sl-feature-strip">
                <div class="sl-feature"><strong>Quality products</strong><span>Practical gear for real training.</span></div>
                <div class="sl-feature"><strong>Expert trainers</strong><span>Find experienced fitness professionals.</span></div>
                <div class="sl-feature"><strong>Supportive community</strong><span>Tools and resources for your journey.</span></div>
            </section>

            <section class="sl-shop" id="shop">
                <div class="sl-section-head">
                    <div>
                        <div class="section-kicker"><?php echo !empty($_GET['search']) ? 'Search results' : 'Shop the collection'; ?></div>
                        <h2 class="section-title"><?php echo !empty($_GET['search']) ? 'Results for “' . htmlspecialchars($_GET['search'], ENT_QUOTES, 'UTF-8') . '”' : 'Featured products'; ?></h2>
                        <p><?php echo !empty($_GET['search']) ? count($products) . ' product' . (count($products) === 1 ? '' : 's') . ' found.' : 'Performance essentials for your next session.'; ?></p>
                    </div>
                    <form class="sl-sort" method="get" action="index.php">
                        <input type="hidden" name="controller" value="home">
                        <input type="hidden" name="action" value="index">
                        <?php if (!empty($_GET['search'])): ?><input type="hidden" name="search" value="<?php echo htmlspecialchars($_GET['search'], ENT_QUOTES, 'UTF-8'); ?>"><?php endif; ?>
                        <label for="sortOrder">Sort</label>
                        <select id="sortOrder" name="sort" onchange="this.form.submit()" aria-label="Sort products">
                            <option value="default" <?php echo empty($_GET['sort']) || $_GET['sort'] === 'default' ? 'selected' : ''; ?>>Featured</option>
                            <option value="alphabetical" <?php echo (($_GET['sort'] ?? '') === 'alphabetical') ? 'selected' : ''; ?>>A–Z</option>
                            <option value="price_asc" <?php echo (($_GET['sort'] ?? '') === 'price_asc') ? 'selected' : ''; ?>>Price: Low</option>
                            <option value="price_desc" <?php echo (($_GET['sort'] ?? '') === 'price_desc') ? 'selected' : ''; ?>>Price: High</option>
                        </select>
                    </form>
                </div>

                <?php
                if (isset($_GET['sort'])) {
                    $sortOrder = $_GET['sort'];
                    if ($sortOrder === 'alphabetical') usort($products, fn($a,$b)=>strcmp($a['product_name'],$b['product_name']));
                    elseif ($sortOrder === 'price_asc') usort($products, fn($a,$b)=>$a['product_price'] <=> $b['product_price']);
                    elseif ($sortOrder === 'price_desc') usort($products, fn($a,$b)=>$b['product_price'] <=> $a['product_price']);
                }
                ?>

                <?php if (empty($products)): ?>
                    <div class="sl-empty-search">
                        <strong>No products found.</strong>
                        <span>Try another search term or browse the full collection.</span>
                        <a class="sl-btn" href="index.php?controller=home&action=index#shop">View all products</a>
                    </div>
                <?php endif; ?>

                <div class="sl-products">
                    <?php foreach ($products as $product): ?>
                        <article class="sl-product">
                            <div class="sl-product-img"><img src="images/<?php echo htmlspecialchars($product['product_image'], ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($product['product_name'], ENT_QUOTES, 'UTF-8'); ?>"></div>
                            <div class="sl-product-body">
                                <h2><?php echo htmlspecialchars($product['product_name'], ENT_QUOTES, 'UTF-8'); ?></h2>
                                <div class="sl-product-desc"><?php echo htmlspecialchars($product['product_description'], ENT_QUOTES, 'UTF-8'); ?></div>
                                <div class="sl-product-meta"><span class="sl-price">$<?php echo htmlspecialchars($product['product_price'], ENT_QUOTES, 'UTF-8'); ?></span><span class="sl-stock"><?php echo (int)$product['product_quantity']; ?> in stock</span></div>
                                <?php if (isset($_SESSION['user'])): ?>
                                    <form class="sl-product-form" action="index.php?controller=cart&action=addProduct" method="post">
                                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
                                        <input type="hidden" name="productId" value="<?php echo (int)$product['product_id']; ?>">
                                        <input type="number" name="quantity" value="1" min="1" max="<?php echo (int)$product['product_quantity']; ?>" aria-label="Quantity">
                                        <button class="sl-btn" type="submit">Add to cart</button>
                                    </form>
                                <?php else: ?>
                                    <a class="sl-btn" href="index.php?controller=user&action=login">Login to shop</a>
                                <?php endif; ?>
                                <a class="sl-product-detail" href="index.php?controller=product&action=viewProduct&id=<?php echo (int)$product['product_id']; ?>">View product →</a>
                                <a class="sl-comments" href="index.php?controller=comment&action=viewComments&product_id=<?php echo (int)$product['product_id']; ?>">View comments →</a>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            </section>

            <section class="sl-service-grid">
                <article id="gyms" class="sl-service-card"><div class="sl-service-image"><img src="images/gymbackground.jpg" alt="Modern gym interior"></div><div class="sl-service-content"><div class="section-kicker">Find your space</div><h3>Find a gym</h3><p>Explore facilities and training options in your area.</p><a class="sl-btn" href="index.php?controller=home&action=otherServices#gyms">Explore gyms →</a></div></article>
                <article id="trainers" class="sl-service-card"><div class="sl-service-image"><img src="images/Muscle.png" alt="Strength training athlete"></div><div class="sl-service-content"><div class="section-kicker">Train smarter</div><h3>Meet our trainers</h3><p>Connect with experienced professionals who can help you move forward.</p><a class="sl-btn" href="index.php?controller=home&action=otherServices#trainers">View trainers →</a></div></article>
            </section>
        </div>
    </main>

    <?php include __DIR__ . '/partials/footer.php'; ?>

</body>
</html>
