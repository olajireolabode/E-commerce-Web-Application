<?php
$productName = $product['product_name'] ?? 'Product';
$productImage = $product['product_image'] ?? '';
$commentCount = count($comments ?? []);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Comments | Silverlight</title>
    <link rel="stylesheet" href="css/silverlight.css">
    <link rel="stylesheet" href="css/viewcomments.css">
</head>
<body>
<?php include __DIR__ . '/../partials/navbar.php'; ?>

<main class="comments-page">
    <div class="comments-shell">
        <div class="comments-breadcrumb">
            <a href="index.php?controller=home&action=index#shop">Shop</a>
            <span>/</span>
            <a href="index.php?controller=product&action=viewProduct&id=<?php echo (int)$productId; ?>">Product</a>
            <span>/</span>
            <strong>Comments</strong>
        </div>

        <section class="comments-hero">
            <div>
                <p class="comments-eyebrow">CUSTOMER FEEDBACK</p>
                <h1>What people<br><span>are saying.</span></h1>
                <p class="comments-intro">Real feedback from the Silverlight community. Read what customers think about this product and join the conversation.</p>
            </div>

            <div class="comments-product-card">
                <?php if ($productImage): ?>
                    <img src="images/<?php echo htmlspecialchars($productImage, ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($productName, ENT_QUOTES, 'UTF-8'); ?>">
                <?php else: ?>
                    <div class="comments-product-placeholder">SL</div>
                <?php endif; ?>
                <div>
                    <span>PRODUCT</span>
                    <strong><?php echo htmlspecialchars($productName, ENT_QUOTES, 'UTF-8'); ?></strong>
                    <a href="index.php?controller=product&action=viewProduct&id=<?php echo (int)$productId; ?>">View product →</a>
                </div>
            </div>
        </section>

        <div class="comments-content">
            <section class="comments-list-card">
                <div class="comments-section-heading">
                    <div>
                        <p class="comments-eyebrow">COMMUNITY</p>
                        <h2>Customer comments</h2>
                    </div>
                    <span class="comments-count"><?php echo $commentCount; ?> <?php echo $commentCount === 1 ? 'comment' : 'comments'; ?></span>
                </div>

                <?php if ($comments): ?>
                    <div class="comment-list">
                    <?php $lastCommentId = null; ?>
                    <?php foreach ($comments as $comment): ?>
                        <?php if ($lastCommentId !== $comment['comment_id']): $lastCommentId = $comment['comment_id']; ?>
                            <article class="comment-card">
                                <div class="comment-avatar"><?php echo strtoupper(substr($comment['user_name'], 0, 1)); ?></div>
                                <div class="comment-main">
                                    <div class="comment-meta">
                                        <div>
                                            <strong><?php echo htmlspecialchars($comment['user_name'], ENT_QUOTES, 'UTF-8'); ?></strong>
                                            <span>Customer</span>
                                        </div>
                                        <?php if (!empty($comment['date_posted'])): ?><time><?php echo htmlspecialchars(date('M j, Y', strtotime($comment['date_posted'])), ENT_QUOTES, 'UTF-8'); ?></time><?php endif; ?>
                                    </div>
                                    <p class="comment-text"><?php echo nl2br(htmlspecialchars($comment['comment'], ENT_QUOTES, 'UTF-8')); ?></p>

                                    <?php if (isset($_SESSION['user']['user_group']) && $_SESSION['user']['user_group'] === 'admin'): ?>
                                        <form action="index.php?controller=comment&action=replyToComment" method="post" class="admin-reply-form">
                                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
                                            <input type="hidden" name="comment_id" value="<?php echo (int)$comment['comment_id']; ?>">
                                            <input type="hidden" name="product_id" value="<?php echo (int)$productId; ?>">
                                            <label for="reply-<?php echo (int)$comment['comment_id']; ?>">ADMIN REPLY</label>
                                            <textarea id="reply-<?php echo (int)$comment['comment_id']; ?>" name="reply" rows="3" placeholder="Write a helpful response..." required></textarea>
                                            <button type="submit" class="sl-btn comment-reply-btn">Reply as admin →</button>
                                        </form>
                                    <?php endif; ?>

                                    <?php if (!empty($comment['reply'])): ?>
                                        <div class="admin-reply">
                                            <div class="admin-reply-mark">SL</div>
                                            <div>
                                                <div class="admin-reply-meta">
                                                    <strong>Silverlight Admin</strong>
                                                    <?php if (!empty($comment['reply_date'])): ?><time><?php echo htmlspecialchars(date('M j, Y', strtotime($comment['reply_date'])), ENT_QUOTES, 'UTF-8'); ?></time><?php endif; ?>
                                                </div>
                                                <p><?php echo nl2br(htmlspecialchars($comment['reply'], ENT_QUOTES, 'UTF-8')); ?></p>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </article>
                        <?php else: ?>
                            <?php if (!empty($comment['reply'])): ?>
                                <div class="admin-reply comment-followup">
                                    <div class="admin-reply-mark">SL</div>
                                    <div>
                                        <div class="admin-reply-meta"><strong>Silverlight Admin</strong></div>
                                        <p><?php echo nl2br(htmlspecialchars($comment['reply'], ENT_QUOTES, 'UTF-8')); ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="comments-empty">
                        <div class="empty-icon">◎</div>
                        <h3>No comments yet.</h3>
                        <p>Be the first person to share your experience with this product.</p>
                    </div>
                <?php endif; ?>
            </section>

            <aside class="comment-form-card">
                <p class="comments-eyebrow">JOIN THE CONVERSATION</p>
                <h2>Share your<br><span>experience.</span></h2>

                <?php if (isset($_SESSION['user']['user_name'])): ?>
                    <p class="form-note">Posting as <strong><?php echo htmlspecialchars($_SESSION['user']['user_name'], ENT_QUOTES, 'UTF-8'); ?></strong></p>
                    <form action="index.php?controller=comment&action=addComment" method="post" class="comment-form">
                        <input type="hidden" name="product_id" value="<?php echo (int)$productId; ?>">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
                        <label for="comment">Your comment</label>
                        <textarea id="comment" name="comment" rows="7" maxlength="512" placeholder="Tell the Silverlight community what you think..." required></textarea>
                        <button type="submit" class="sl-btn comment-submit">Post comment →</button>
                    </form>
                <?php else: ?>
                    <p class="form-note">You need an account to leave a comment. Sign in to share your experience with the community.</p>
                    <a class="sl-btn comment-submit" href="index.php?controller=user&action=login">Log in to comment →</a>
                    <a class="comment-register" href="index.php?controller=user&action=registerForm">Don't have an account? Join Silverlight</a>
                <?php endif; ?>

                <div class="comment-guidelines">
                    <span>COMMUNITY GUIDELINES</span>
                    <p>Keep feedback respectful, useful, and relevant to the product.</p>
                </div>
            </aside>
        </div>
    </div>
</main>

<?php include __DIR__ . '/../partials/footer.php'; ?>
</body>
</html>
