<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart | Silverlight</title>
    <link rel="stylesheet" href="css/silverlight.css">
    <link rel="stylesheet" href="css/Cart.css">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>

<main class="cart-page page-shell">
    <header class="cart-header">
        <div>
            <div class="section-kicker">Your selection</div>
            <h1 class="section-title">Shopping Cart</h1>
            <p class="cart-subtitle">Review your gear and supplements before you check out.</p>
        </div>
        <a class="cart-continue" href="index.php?controller=home&action=index#shop">← Continue shopping</a>
    </header>

    <?php if (empty($user_cart)): ?>
        <section class="cart-empty sl-card">
            <div class="cart-empty-icon">🛒</div>
            <div class="section-kicker">Nothing here yet</div>
            <h2>Your cart is empty.</h2>
            <p>Find something that helps you train harder, recover better, and keep moving.</p>
            <a class="sl-btn" href="index.php?controller=home&action=index#shop">Shop products →</a>
        </section>
    <?php else: ?>
        <?php $cart_total = 0; $cart_items_count = 0; ?>
        <div class="cart-layout">
            <section class="cart-items" aria-label="Shopping cart items">
                <?php foreach ($user_cart as $cart_item): ?>
                    <?php
                        $quantity = (int)$cart_item['quantity'];
                        $price = (float)$cart_item['product_price'];
                        $line_total = $price * $quantity;
                        $cart_total += $line_total;
                        $cart_items_count += $quantity;
                        $description = trim((string)$cart_item['product_description']);
                        $short_description = strlen($description) > 95 ? substr($description, 0, 95) . '...' : $description;
                    ?>
                    <article class="cart-item sl-card">
                        <div class="cart-item-image">
                            <img src="images/<?php echo htmlspecialchars($cart_item['product_image'], ENT_QUOTES, 'UTF-8'); ?>"
                                 alt="<?php echo htmlspecialchars($cart_item['product_name'], ENT_QUOTES, 'UTF-8'); ?>">
                        </div>

                        <div class="cart-item-info">
                            <div class="cart-item-kicker">Silverlight collection</div>
                            <h2><?php echo htmlspecialchars($cart_item['product_name'], ENT_QUOTES, 'UTF-8'); ?></h2>
                            <p><?php echo htmlspecialchars($short_description, ENT_QUOTES, 'UTF-8'); ?></p>
                            <span class="cart-unit-price">$<?php echo number_format($price, 2); ?> each</span>
                        </div>

                        <div class="cart-item-controls">
                            <span class="control-label">Quantity</span>
                            <div class="quantity-control">
                                <button type="button" class="quantity-btn" aria-label="Decrease quantity"
                                    onclick="updateQuantity(-1,'form<?php echo (int)$cart_item['pk']; ?>',<?php echo (int)$cart_item['pk']; ?>,<?php echo $price; ?>)">−</button>
                                <input id="form<?php echo (int)$cart_item['pk']; ?>" min="0" max="<?php echo (int)$cart_item['product_quantity']; ?>"
                                       value="<?php echo $quantity; ?>" type="number" aria-label="Quantity for <?php echo htmlspecialchars($cart_item['product_name'], ENT_QUOTES, 'UTF-8'); ?>">
                                <button type="button" class="quantity-btn" aria-label="Increase quantity"
                                    onclick="updateQuantity(1,'form<?php echo (int)$cart_item['pk']; ?>',<?php echo (int)$cart_item['pk']; ?>,<?php echo $price; ?>)">+</button>
                            </div>
                        </div>

                        <div class="cart-item-total">
                            <span class="control-label">Total</span>
                            <strong id="totalAmount<?php echo (int)$cart_item['pk']; ?>">$<?php echo number_format($line_total, 2); ?></strong>
                        </div>

                        <form class="cart-remove" action="index.php?controller=cart&action=deleteItem" method="post">
                            <input type="hidden" name="id" value="<?php echo (int)$cart_item['pk']; ?>">
                            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
                            <button type="submit" aria-label="Remove <?php echo htmlspecialchars($cart_item['product_name'], ENT_QUOTES, 'UTF-8'); ?>">×</button>
                        </form>
                    </article>
                <?php endforeach; ?>
            </section>

            <aside class="cart-summary sl-card">
                <div class="section-kicker">Order summary</div>
                <h2>Ready to train?</h2>
                <div class="summary-row">
                    <span>Items</span>
                    <strong><?php echo $cart_items_count; ?></strong>
                </div>
                <div class="summary-row summary-total">
                    <span>Total</span>
                    <strong>$<?php echo number_format($cart_total, 2); ?></strong>
                </div>
                <a class="sl-btn cart-checkout" href="index.php?controller=cart&action=checkout">Proceed to checkout →</a>
                <p class="cart-demo-note">Secure demo checkout. No real payment is collected.</p>
            </aside>
        </div>
    <?php endif; ?>
</main>

<?php include __DIR__ . '/partials/footer.php'; ?>

<script>
function updateQuantity(change, id, no, productPrice) {
    const quantityInput = document.getElementById(id);
    const currentQuantity = parseInt(quantityInput.value, 10) || 0;
    const maxQuantity = parseInt(quantityInput.max, 10) || 9999;
    let newQuantity = Math.max(0, Math.min(currentQuantity + change, maxQuantity));
    quantityInput.value = newQuantity;

    const totalAmount = document.getElementById('totalAmount' + no);
    if (totalAmount) totalAmount.textContent = '$' + (newQuantity * productPrice).toFixed(2);

    fetch('index.php?controller=cart&action=updateCount', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: new URLSearchParams({
            id: no,
            quantity: newQuantity,
            csrf_token: '<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>'
        })
    })
    .then(response => response.json())
    .then(data => {
        if (!data.success) {
            alert(data.message || 'Unable to update the cart.');
            window.location.reload();
            return;
        }
        if (data.quantity === 0) window.location.reload();
    })
    .catch(() => {
        alert('Unable to update the cart. Please try again.');
        window.location.reload();
    });
}
</script>
</body>
</html>
