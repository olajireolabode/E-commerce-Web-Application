<footer class="sl-footer">
    <div class="sl-footer-inner">
        <div>
            <div class="brand"><span class="brand-mark">SL</span><span class="brand-word">SILVER<span>LIGHT</span></span></div>
            <p>Train harder. Live stronger.</p>
        </div>
        <div class="sl-footer-links">
            <a href="index.php?controller=home&action=index#shop">Shop</a>
            <a href="index.php?controller=home&action=otherServices#gyms">Gyms</a>
            <a href="index.php?controller=home&action=otherServices#trainers">Trainers</a>
            <a href="index.php?controller=home&action=contactUs">Contact</a>
            <a href="index.php?controller=home&action=aboutUs">About</a>
        </div>
    </div>
</footer>
