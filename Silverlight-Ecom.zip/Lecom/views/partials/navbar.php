<?php
$navController = $_GET['controller'] ?? 'home';
$navAction = $_GET['action'] ?? 'index';
$isLoggedIn = isset($_SESSION['user']['user_name']);
$isAdmin = $isLoggedIn && (($_SESSION['user']['user_group'] ?? '') === 'admin');

function nav_active($controller, $action = null) {
    global $navController, $navAction;
    if ($action === null) {
        return $navController === $controller;
    }
    return $navController === $controller && $navAction === $action;
}

$cartCount = 0;
if ($isLoggedIn && isset($_SESSION['cart_count'])) {
    $cartCount = (int)$_SESSION['cart_count'];
}
?>
<header class="site-header">
    <nav class="site-nav" aria-label="Primary navigation">
        <a class="brand" href="index.php?controller=home&action=index" aria-label="Silverlight home">
            <span class="brand-mark" aria-hidden="true">SL</span>
            <span class="brand-word">SILVER<span>LIGHT</span></span>
        </a>

        <button class="nav-toggle" type="button" aria-label="Open navigation" aria-expanded="false" aria-controls="site-menu">
            <span></span><span></span><span></span>
        </button>

        <div class="nav-menu" id="site-menu">
            <div class="nav-links">
                <a class="nav-link <?php echo nav_active('home', 'index') ? 'is-active' : ''; ?>" href="index.php?controller=home&action=index">Home</a>
                <a class="nav-link" href="index.php?controller=home&action=index#shop">Shop</a>
                <a class="nav-link <?php echo nav_active('home', 'otherServices') ? 'is-active' : ''; ?>" href="index.php?controller=home&action=otherServices#gyms">Gyms</a>
                <a class="nav-link" href="index.php?controller=home&action=otherServices#trainers">Trainers</a>
                <a class="nav-link <?php echo nav_active('home', 'bmiCalculator') ? 'is-active' : ''; ?>" href="index.php?controller=home&action=bmiCalculator">BMI</a>
                <a class="nav-link <?php echo nav_active('home', 'contactUs') ? 'is-active' : ''; ?>" href="index.php?controller=home&action=contactUs">Contact</a>
                <a class="nav-link <?php echo nav_active('home', 'aboutUs') ? 'is-active' : ''; ?>" href="index.php?controller=home&action=aboutUs">About</a>
            </div>

            <div class="nav-actions">
                <form class="nav-search" method="get" action="index.php" role="search">
                    <input type="hidden" name="controller" value="home">
                    <input type="hidden" name="action" value="index">
                    <input type="search" name="search" value="<?php echo htmlspecialchars($_GET['search'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" placeholder="Search products..." aria-label="Search products">
                    <button type="submit" aria-label="Search">⌕</button>
                </form>

                <a class="icon-link cart-link" href="<?php echo $isLoggedIn ? 'index.php?controller=cart&action=viewCart' : 'index.php?controller=user&action=login'; ?>" aria-label="Shopping cart">
                    <span class="nav-icon" aria-hidden="true">🛒</span>
                    <span class="cart-label">Cart</span>
                    <?php if ($cartCount > 0): ?><span class="cart-badge"><?php echo $cartCount; ?></span><?php endif; ?>
                </a>

                <?php if ($isLoggedIn): ?>
                    <div class="account-menu">
                        <button class="account-button" type="button" aria-expanded="false">
                            <span class="account-avatar" aria-hidden="true">●</span>
                            <span><?php echo htmlspecialchars($_SESSION['user']['user_name'], ENT_QUOTES, 'UTF-8'); ?></span>
                            <span class="chevron">⌄</span>
                        </button>
                        <div class="account-dropdown">
                            <?php if ($isAdmin): ?>
                                <a href="index.php?controller=admin&action=dashboard">Admin Dashboard</a>
                            <?php endif; ?>
                            <a href="index.php?controller=cart&action=viewCart">My Cart</a>
                            <a class="dropdown-danger" href="logout.php">Log out</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a class="login-link" href="index.php?controller=user&action=login">Log in</a>
                    <a class="nav-cta" href="index.php?controller=user&action=registerForm">Join now</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
</header>
<script>
(function () {
    var toggle = document.querySelector('.nav-toggle');
    var menu = document.querySelector('.nav-menu');
    if (toggle && menu && !toggle.dataset.bound) {
        toggle.dataset.bound = '1';
        toggle.addEventListener('click', function () {
            var open = menu.classList.toggle('is-open');
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
        menu.querySelectorAll('a').forEach(function (link) {
            link.addEventListener('click', function () {
                menu.classList.remove('is-open');
                toggle.setAttribute('aria-expanded', 'false');
            });
        });
    }
})();
</script>
