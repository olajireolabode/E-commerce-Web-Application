<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log in | Silverlight</title>
    <link rel="stylesheet" href="css/silverlight.css">
    <link rel="stylesheet" href="css/Auth.css">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>

<main class="auth-page">
    <section class="auth-shell" aria-labelledby="login-title">
        <div class="auth-visual auth-login-visual">
            <div class="auth-visual-content">
                <p class="auth-kicker">Discipline builds freedom</p>
                <h2>Welcome<br>back<span>.</span></h2>
                <p>Sign in to keep building your stronger self, manage your cart, and continue your Silverlight journey.</p>
            </div>
        </div>

        <div class="auth-form-panel">
            <div class="auth-form-wrap">
                <div class="auth-brandline">
                    <span class="brand-mark" aria-hidden="true">SL</span>
                    <strong>SILVERLIGHT</strong>
                </div>

                <div class="auth-heading">
                    <p class="eyebrow">Member access</p>
                    <h1 id="login-title">Log in</h1>
                    <p>Welcome back. Enter your details to access your account.</p>
                </div>

                <?php if (isset($_GET['error'])): ?>
                    <div class="auth-alert" role="alert">
                        <?php echo htmlspecialchars($_GET['error'], ENT_QUOTES, 'UTF-8'); ?>
                    </div>
                <?php endif; ?>

                <form class="auth-form" action="index.php?controller=user&action=authenticate" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">

                    <div class="auth-field">
                        <label for="usernameOrEmail">Username or email</label>
                        <input id="usernameOrEmail" type="text" name="usernameOrEmail" autocomplete="username" required autofocus placeholder="Enter your username or email">
                    </div>

                    <div class="auth-field">
                        <label for="password">Password</label>
                        <input id="password" type="password" name="password" autocomplete="current-password" required placeholder="Enter your password">
                    </div>

                    <button class="auth-submit" type="submit">Log in →</button>
                </form>

                <p class="auth-switch">Don't have an account? <a href="index.php?controller=user&action=registerForm">Create one</a></p>
            </div>
        </div>
    </section>
</main>

<?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
