<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Silverlight | Gyms & Trainers</title>
    <link rel="stylesheet" href="css/silverlight.css">
    <link rel="stylesheet" href="css/Services-Silverlight.css">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>
<main class="page-shell services-page">
    <header class="services-hero">
        <div><div class="section-kicker">Train with purpose</div><h1>Find your <span>people.</span></h1></div>
        <p class="services-hero-copy">Discover affiliated gyms and experienced trainers from the Silverlight community. The goal is simple: make it easier to find a place and a plan that keep you moving.</p>
    </header>
    <section id="gyms" class="service-section">
        <div class="service-section-head"><div><div class="section-kicker">01 / Find your space</div><h2>Affiliated gyms</h2></div><p><?php echo !empty($gyms) ? count($gyms) . ' locations' : 'No locations'; ?></p></div>
        <?php if (!empty($gyms)): ?><div class="gym-list"><?php foreach ($gyms as $i => $gym): ?><article class="gym-card"><div class="gym-index">GYM <?php echo str_pad((string)($i + 1), 2, '0', STR_PAD_LEFT); ?></div><h3><?php echo htmlspecialchars($gym['gym_name'], ENT_QUOTES, 'UTF-8'); ?></h3><div class="gym-meta"><div><strong>Location</strong> <?php echo htmlspecialchars($gym['location_number'] . ', ' . $gym['street_name'] . ', ' . $gym['city'] . ' ' . $gym['zip'], ENT_QUOTES, 'UTF-8'); ?></div><div><strong>Phone</strong> <?php echo htmlspecialchars($gym['office_number'], ENT_QUOTES, 'UTF-8'); ?></div><div><strong>Email</strong> <?php echo htmlspecialchars($gym['email'], ENT_QUOTES, 'UTF-8'); ?></div></div></article><?php endforeach; ?></div><?php else: ?><div class="empty-state">No affiliated gyms are available right now.</div><?php endif; ?>
    </section>
    <section id="trainers" class="service-section">
        <div class="service-section-head"><div><div class="section-kicker">02 / Train smarter</div><h2>Meet the trainers</h2></div><p><?php echo !empty($trainers) ? count($trainers) . ' professionals' : 'No trainers'; ?></p></div>
        <?php if (!empty($trainers)): ?><div class="trainer-grid"><?php foreach ($trainers as $trainer): ?><article class="trainer-card"><div class="trainer-image"><img src="images/profile_image.png" alt="Trainer profile"></div><div class="trainer-content"><div class="trainer-label">Personal trainer</div><h3><?php echo htmlspecialchars($trainer['trainer_name'], ENT_QUOTES, 'UTF-8'); ?></h3><p><strong>Qualification</strong> <?php echo htmlspecialchars($trainer['trainer_qualification'], ENT_QUOTES, 'UTF-8'); ?></p><p><strong>Location</strong> <?php echo htmlspecialchars($trainer['location_number'] . ', ' . $trainer['street_name'] . ', ' . $trainer['city'] . ' ' . $trainer['zip'], ENT_QUOTES, 'UTF-8'); ?></p><p><strong>Phone</strong> <?php echo htmlspecialchars($trainer['phone_number'], ENT_QUOTES, 'UTF-8'); ?></p><p><strong>Email</strong> <?php echo htmlspecialchars($trainer['email'], ENT_QUOTES, 'UTF-8'); ?></p></div></article><?php endforeach; ?></div><?php else: ?><div class="empty-state">No trainers are available right now.</div><?php endif; ?>
    </section>
</main>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
