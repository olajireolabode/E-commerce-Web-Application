<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About | Silverlight</title>
  <link rel="stylesheet" href="css/silverlight.css">
  <style>
    .about-page{padding:72px 0 20px}
    .about-hero{display:grid;grid-template-columns:1.15fr .85fr;gap:24px;align-items:stretch;margin-bottom:22px}
    .about-intro,.about-side,.about-card{background:linear-gradient(145deg,#14181a,#0e1113);border:1px solid var(--sl-border);border-radius:14px;box-shadow:var(--sl-shadow)}
    .about-intro{padding:clamp(30px,5vw,62px);min-height:390px;display:flex;flex-direction:column;justify-content:center;position:relative;overflow:hidden}
    .about-intro:after{content:'SL';position:absolute;right:-15px;bottom:-55px;font:900 250px/.8 'Barlow Condensed',sans-serif;color:rgba(255,59,48,.055);pointer-events:none}
    .about-intro h1{font:900 clamp(60px,8vw,112px)/.82 'Barlow Condensed',sans-serif;text-transform:uppercase;margin:12px 0 22px;max-width:720px;position:relative;z-index:1}
    .about-intro h1 span{color:var(--sl-red)}
    .about-intro p{max-width:650px;color:#aeb5b8;line-height:1.8;font-size:14px;position:relative;z-index:1}
    .about-side{padding:30px;display:flex;flex-direction:column;justify-content:space-between;min-height:330px}
    .about-side-number{font:800 72px/.8 'Barlow Condensed',sans-serif;color:var(--sl-red)}
    .about-side h2,.about-card h2{font:800 34px/.95 'Barlow Condensed',sans-serif;text-transform:uppercase;margin:18px 0 10px}
    .about-side p,.about-card p{color:#9da4a8;line-height:1.75;font-size:13px;margin:0}
    .about-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
    .about-card{padding:28px;min-height:205px}
    .about-card-index{color:var(--sl-red);font:800 12px 'Barlow Condensed',sans-serif;letter-spacing:.12em}
    .about-card h2{font-size:28px}
    .about-note{margin-top:18px;padding:20px 22px;border-left:3px solid var(--sl-red);background:#0d1011;color:#aeb5b8;font-size:12px;line-height:1.7}
    @media(max-width:850px){.about-hero{grid-template-columns:1fr}.about-side{min-height:230px}.about-grid{grid-template-columns:1fr}}
    @media(max-width:600px){.about-page{padding-top:42px}.about-intro{min-height:460px;padding:28px}.about-intro h1{font-size:70px}.about-side,.about-card{padding:24px}}
  </style>
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>
<main class="page-shell about-page">
  <section class="about-hero">
    <article class="about-intro">
      <div class="section-kicker">The Silverlight story</div>
      <h1>Built for the <span>journey.</span></h1>
      <p>Silverlight is a fitness-focused e-commerce and community platform designed to bring products, training resources and practical wellness tools into one place.</p>
      <div class="about-note">Train harder. Live stronger. The project combines a transactional storefront with fitness services so users can discover products, gyms, trainers and resources without jumping between different platforms.</div>
    </article>
    <aside class="about-side">
      <div><div class="about-side-number">01</div><h2>One place. More momentum.</h2><p>From performance products to trainer and gym information, Silverlight is designed around the full fitness journey rather than a single purchase.</p></div>
      <a class="sl-btn" href="index.php?controller=home&action=index#shop">Explore the store →</a>
    </aside>
  </section>

  <section class="about-grid" aria-label="Silverlight features">
    <article class="about-card"><div class="about-card-index">01 / PRODUCTS</div><h2>Performance essentials</h2><p>Browse supplements, training equipment, apparel and other fitness-focused products through a structured online storefront.</p></article>
    <article class="about-card"><div class="about-card-index">02 / SERVICES</div><h2>People & places</h2><p>Discover affiliated gyms and trainer profiles with contact and location information to help turn motivation into action.</p></article>
    <article class="about-card"><div class="about-card-index">03 / TOOLS</div><h2>Useful resources</h2><p>Use features such as the BMI calculator, customer comments and support messaging to make the platform more interactive.</p></article>
  </section>
</main>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
