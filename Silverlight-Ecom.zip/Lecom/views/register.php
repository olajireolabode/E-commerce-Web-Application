<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create account | Silverlight</title>
    <link rel="stylesheet" href="css/silverlight.css">
    <link rel="stylesheet" href="css/Auth.css">
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>

<main class="auth-page">
    <section class="auth-shell" aria-labelledby="register-title">
        <div class="auth-visual auth-register-visual">
            <div class="auth-visual-content">
                <p class="auth-kicker">Start your journey</p>
                <h2>Get<br>stronger<span>.</span></h2>
                <p>Create your Silverlight account and get access to fitness products, gyms, trainers, and your personal shopping experience.</p>
            </div>
        </div>

        <div class="auth-form-panel">
            <div class="auth-form-wrap">
                <div class="auth-brandline">
                    <span class="brand-mark" aria-hidden="true">SL</span>
                    <strong>SILVERLIGHT</strong>
                </div>

                <div class="auth-heading">
                    <p class="eyebrow">New member</p>
                    <h1 id="register-title">Join Silverlight</h1>
                    <p>Create your account and start your journey.</p>
                </div>

                <?php if (isset($_GET['error'])): ?>
                    <div class="auth-alert" role="alert">
                        <?php echo htmlspecialchars($_GET['error'], ENT_QUOTES, 'UTF-8'); ?>
                    </div>
                <?php endif; ?>

                <form class="auth-form" action="index.php?controller=user&action=register" method="post">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">

                    <div class="auth-field">
                        <label for="username">Username</label>
                        <input id="username" type="text" name="username" autocomplete="username" minlength="3" required autofocus placeholder="Choose a username">
                    </div>

                    <div class="auth-field">
                        <label for="email">Email</label>
                        <input id="email" type="email" name="email" autocomplete="email" required placeholder="you@example.com">
                    </div>

                    <div class="auth-field">
                        <label for="password">Password</label>
                        <input id="password" type="password" name="password" autocomplete="new-password" minlength="8" required placeholder="At least 8 characters">
                    </div>

                    <div class="auth-field">
                        <label for="confirmPassword">Confirm password</label>
                        <input id="confirmPassword" type="password" name="confirmPassword" autocomplete="new-password" minlength="8" required placeholder="Enter your password again">
                    </div>

                    <p class="auth-note">Public registration creates a standard member account. Administrator access is managed separately.</p>
                    <button class="auth-submit" type="submit">Create account →</button>
                </form>

                <p class="auth-switch">Already have an account? <a href="index.php?controller=user&action=login">Log in</a></p>
            </div>
        </div>
    </section>
</main>

<?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
