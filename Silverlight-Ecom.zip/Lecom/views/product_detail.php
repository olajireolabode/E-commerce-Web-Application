<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['product_name'], ENT_QUOTES, 'UTF-8'); ?> | Silverlight</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/silverlight.css">
    <style>
        .product-page{padding:54px 0 80px}.product-breadcrumb{color:var(--sl-muted);font-size:11px;text-transform:uppercase;letter-spacing:.08em;margin-bottom:22px}.product-breadcrumb a{color:#aeb5b8;text-decoration:none}.product-breadcrumb a:hover{color:#fff}.product-detail{display:grid;grid-template-columns:minmax(0,1.05fr) minmax(0,.95fr);gap:28px;align-items:stretch}.product-media{min-height:560px;background:radial-gradient(circle at 50% 35%,#1b2226 0,#0c0f11 58%,#080a0b 100%);border:1px solid var(--sl-border);border-radius:14px;display:grid;place-items:center;padding:42px;overflow:hidden}.product-media img{width:100%;height:100%;max-height:500px;object-fit:contain}.product-info{padding:20px 4px}.product-kicker{color:var(--sl-red);font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.16em}.product-info h1{font-family:'Barlow Condensed',sans-serif;text-transform:uppercase;font-size:clamp(52px,6vw,82px);line-height:.88;margin:10px 0 18px}.product-price{font-size:32px;font-weight:900;margin-bottom:8px}.product-stock{font-size:11px;color:var(--sl-green);text-transform:uppercase;letter-spacing:.08em;font-weight:800;margin-bottom:22px}.product-description{color:#aeb5b8;line-height:1.8;font-size:14px;max-width:620px;border-top:1px solid var(--sl-border);border-bottom:1px solid var(--sl-border);padding:22px 0;margin-bottom:24px}.product-buy{display:flex;gap:10px;align-items:center;max-width:440px}.product-buy input{width:84px!important;padding:13px!important}.product-buy .sl-btn{flex:1}.product-links{display:flex;gap:18px;margin-top:18px;flex-wrap:wrap}.product-links a{color:#aeb5b8;font-size:11px;text-transform:uppercase;font-weight:800;text-decoration:none}.product-links a:hover{color:#fff}.detail-note{margin-top:30px;padding:18px;border:1px solid var(--sl-border);background:#0e1113;border-radius:10px;color:#899296;font-size:11px;line-height:1.6}@media(max-width:800px){.product-detail{grid-template-columns:1fr}.product-media{min-height:390px}.product-info h1{font-size:58px}}
    </style>
</head>
<body>
<?php include __DIR__ . '/partials/navbar.php'; ?>
<main class="page-shell product-page">
    <div class="product-breadcrumb"><a href="index.php?controller=home&action=index#shop">Shop</a> &nbsp;/&nbsp; <?php echo htmlspecialchars($product['product_name'], ENT_QUOTES, 'UTF-8'); ?></div>
    <section class="product-detail">
        <div class="product-media">
            <img src="images/<?php echo htmlspecialchars($product['product_image'], ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($product['product_name'], ENT_QUOTES, 'UTF-8'); ?>">
        </div>
        <div class="product-info">
            <div class="product-kicker">Silverlight performance collection</div>
            <h1><?php echo htmlspecialchars($product['product_name'], ENT_QUOTES, 'UTF-8'); ?></h1>
            <div class="product-price">$<?php echo number_format((float)$product['product_price'], 2); ?></div>
            <div class="product-stock"><?php echo (int)$product['product_quantity']; ?> in stock</div>
            <div class="product-description"><?php echo nl2br(htmlspecialchars($product['product_description'], ENT_QUOTES, 'UTF-8')); ?></div>

            <?php if ((int)$product['product_quantity'] > 0): ?>
                <?php if (isset($_SESSION['user'])): ?>
                    <form class="product-buy" action="index.php?controller=cart&action=addProduct" method="post">
                        <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">
                        <input type="hidden" name="productId" value="<?php echo (int)$product['product_id']; ?>">
                        <input type="number" name="quantity" value="1" min="1" max="<?php echo (int)$product['product_quantity']; ?>" aria-label="Quantity">
                        <button class="sl-btn" type="submit">Add to cart →</button>
                    </form>
                <?php else: ?>
                    <a class="sl-btn" href="index.php?controller=user&action=login">Log in to shop →</a>
                <?php endif; ?>
            <?php else: ?>
                <div class="detail-note">This product is currently out of stock. Check back soon for availability.</div>
            <?php endif; ?>

            <div class="product-links">
                <a href="index.php?controller=comment&action=viewComments&product_id=<?php echo (int)$product['product_id']; ?>">View customer comments →</a>
                <a href="index.php?controller=home&action=index#shop">← Back to shop</a>
            </div>
        </div>
    </section>
</main>
<?php include __DIR__ . '/partials/footer.php'; ?>
</body>
</html>
