<header class="admin-topbar">
  <div class="admin-brand"><span class="admin-brand-mark">S</span><div><strong>SILVERLIGHT</strong><small>ADMIN CONTROL</small></div></div>
  <button class="admin-menu" type="button" aria-label="Toggle admin menu" onclick="document.body.classList.toggle('admin-nav-open')">☰</button>
  <nav class="admin-nav">
    <a href="index.php?controller=admin&action=dashboard">Dashboard</a>
    <a href="index.php?controller=product&action=displayDetails">Products</a>
    <a href="index.php?controller=gym&action=displayDetails">Gyms</a>
    <a href="index.php?controller=trainer&action=displayDetails">Trainers</a>
    <a href="index.php?controller=admin&action=usermessage">Messages</a>
    <a href="index.php?controller=home&action=index">View Site</a>
    <a class="admin-logout" href="logout.php">Logout</a>
  </nav>
</header>
