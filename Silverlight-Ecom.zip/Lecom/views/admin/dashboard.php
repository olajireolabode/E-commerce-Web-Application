<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Silverlight Admin Dashboard</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700;800;900&family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/silverlight.css"><link rel="stylesheet" href="css/admin-silverlight.css">
</head>
<body class="admin-page">
<?php include __DIR__ . '/partials/nav.php'; ?>
<main class="admin-main">
  <div class="admin-heading">
    <div><p class="admin-kicker">Silverlight / Control center</p><h1>Run the <span>platform.</span></h1></div>
    <div><p>Manage the store, fitness directory and customer activity from one place. Everything here is connected to your existing Silverlight database.</p></div>
  </div>
  <div class="admin-actions" style="margin-bottom:28px">
    <a class="admin-btn" href="index.php?controller=product&action=insertForm">+ Add product</a>
    <a class="admin-btn secondary" href="index.php?controller=gym&action=insertForm">+ Add gym</a>
    <a class="admin-btn secondary" href="index.php?controller=trainer&action=insertForm">+ Add trainer</a>
  </div>
  <section class="admin-stats">
    <article class="admin-stat accent"><span class="admin-stat-label">Products</span><strong><?php echo $stats['products']; ?></strong><small>Live catalog items</small></article>
    <article class="admin-stat"><span class="admin-stat-label">Orders</span><strong><?php echo $stats['orders']; ?></strong><small>Orders recorded</small></article>
    <article class="admin-stat"><span class="admin-stat-label">Users</span><strong><?php echo $stats['users']; ?></strong><small><?php echo $stats['admins']; ?> admin accounts</small></article>
    <article class="admin-stat"><span class="admin-stat-label">Messages</span><strong><?php echo $stats['messages']; ?></strong><small>Customer enquiries</small></article>
  </section>
  <section class="admin-grid">
    <div class="admin-panel">
      <div class="admin-panel-head"><h2>Recent orders</h2><span>Latest 6</span></div>
      <div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Order</th><th>Customer</th><th>Date</th><th>Total</th></tr></thead><tbody>
      <?php if (empty($recentOrders)): ?><tr><td colspan="4">No orders have been placed yet.</td></tr>
      <?php else: foreach ($recentOrders as $order): ?><tr><td>#<?php echo (int)$order['order_id']; ?></td><td><?php echo htmlspecialchars($order['user_name'] ?: 'Guest', ENT_QUOTES, 'UTF-8'); ?></td><td><?php echo htmlspecialchars($order['order_date'], ENT_QUOTES, 'UTF-8'); ?></td><td>$<?php echo number_format((float)$order['total'], 2); ?></td></tr><?php endforeach; endif; ?>
      </tbody></table></div>
    </div>
    <aside class="admin-panel">
      <div class="admin-panel-head"><h2>System pulse</h2><span>Live counts</span></div>
      <div class="admin-side-list">
        <div class="admin-side-row"><div><strong>Gyms</strong><span>Directory listings</span></div><b class="admin-number"><?php echo $stats['gyms']; ?></b></div>
        <div class="admin-side-row"><div><strong>Trainers</strong><span>Fitness professionals</span></div><b class="admin-number"><?php echo $stats['trainers']; ?></b></div>
        <div class="admin-side-row"><div><strong>Low stock</strong><span>10 units or fewer</span></div><b class="admin-number"><?php echo $stats['low_stock']; ?></b></div>
        <div class="admin-side-row"><div><strong>Admins</strong><span>Privileged accounts</span></div><b class="admin-number"><?php echo $stats['admins']; ?></b></div>
      </div>
      <div class="admin-panel-head"><h2>Quick access</h2><span>Manage</span></div>
      <div class="admin-quick">
        <a href="index.php?controller=product&action=displayDetails"><strong>Products</strong><span>Edit stock, pricing and catalog.</span></a>
        <a href="index.php?controller=gym&action=displayDetails"><strong>Gyms</strong><span>Manage locations and listings.</span></a>
        <a href="index.php?controller=trainer&action=displayDetails"><strong>Trainers</strong><span>Update trainer profiles.</span></a>
        <a href="index.php?controller=admin&action=usermessage"><strong>Messages</strong><span>Reply to customer questions.</span></a>
      </div>
    </aside>
  </section>
  <section class="admin-panel" style="margin-top:18px">
    <div class="admin-panel-head"><h2>User management</h2><span><?php echo count($users); ?> loaded</span></div>
    <div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Username</th><th>Email</th><th>Role</th><th>Action</th></tr></thead><tbody>
    <?php foreach ($users as $user): ?><tr><td><?php echo htmlspecialchars($user['user_name'], ENT_QUOTES, 'UTF-8'); ?></td><td><?php echo htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?></td><td><span class="admin-role <?php echo $user['user_group']==='admin'?'admin':''; ?>"><?php echo htmlspecialchars($user['user_group'], ENT_QUOTES, 'UTF-8'); ?></span></td><td><?php if ($user['user_group'] !== 'admin'): ?><form method="post" action="index.php?controller=admin&action=promoteUser"><input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8'); ?>"><input type="hidden" name="username" value="<?php echo htmlspecialchars($user['user_name'], ENT_QUOTES, 'UTF-8'); ?>"><button class="admin-user-action" type="submit">Promote to admin</button></form><?php else: ?><span class="admin-role admin">Administrator</span><?php endif; ?></td></tr><?php endforeach; ?>
    </tbody></table></div>
  </section>
</main><footer class="admin-footer">Silverlight Admin • Secure management area</footer>
</body></html>
