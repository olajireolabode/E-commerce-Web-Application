<?php
// Silverlight database configuration.
// Environment variables are used in production; the defaults keep XAMPP local setup working.
$dbHost = getenv('SILVERLIGHT_DB_HOST') ?: 'localhost';
$dbName = getenv('SILVERLIGHT_DB_NAME') ?: 'silverlight';
$dbUser = getenv('SILVERLIGHT_DB_USER') ?: 'root';
$dbPass = getenv('SILVERLIGHT_DB_PASS') ?: '';

$dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";

try {
    $db = new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    error_log('Silverlight database connection failed: ' . $e->getMessage());
    exit('Silverlight is temporarily unable to connect to its database. Please try again later.');
}
