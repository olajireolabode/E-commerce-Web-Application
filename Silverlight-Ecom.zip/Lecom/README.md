# SILVERLIGHT

Silverlight is a PHP + MySQL fitness e-commerce web application redesigned with a dark athletic interface.

## Features

- Responsive fitness storefront
- Product catalog and product detail pages
- Product sorting
- Shopping cart with quantity controls
- Inventory protection
- Checkout and demo-order confirmation
- User registration and login
- Password hashing
- CSRF protection
- Customer comments and admin replies
- Contact/support messaging
- BMI calculator
- Gym and trainer directories
- Admin dashboard
- Admin product, gym and trainer management
- Admin user and message management
- Responsive mobile navigation

## Local setup with XAMPP

1. Copy the `Lecom` folder into `C:\xampp\htdocs\`.
2. Start **Apache** and **MySQL** in XAMPP.
3. Open phpMyAdmin and create a database named `silverlight`.
4. Import `silverlight.sql` into that database.
5. Open:
   `http://localhost/Lecom/`

The project uses XAMPP-friendly defaults (`localhost`, database `silverlight`, user `root`, empty password), so no environment configuration is required for a standard local setup.

## Production database configuration

The application reads these environment variables when they are available:

- `SILVERLIGHT_DB_HOST`
- `SILVERLIGHT_DB_NAME`
- `SILVERLIGHT_DB_USER`
- `SILVERLIGHT_DB_PASS`

See `.env.example` for the expected names. **Never commit real production database credentials.**

Import `silverlight.sql` into the MySQL/MariaDB database supplied by your host, then set the environment variables in the host's PHP/application settings.

## Deployment notes

Silverlight requires:

- PHP with PDO MySQL support
- MySQL or MariaDB
- Sessions enabled
- A web server capable of serving PHP

Before deploying, update the database environment variables and verify that the host allows PHP sessions and database connections.

## Demo payment

Checkout is intentionally a portfolio/demo flow. It does **not** process real credit-card payments and does not store the shipping fields entered on the demo checkout page.

## Security notes

- Passwords are stored using PHP's `password_hash()`.
- POST forms use CSRF tokens where required.
- Admin-only operations check the authenticated user's admin role.
- Destructive admin actions use POST requests.
- Database queries use PDO prepared statements.
- Production database errors are logged server-side instead of exposing connection details to visitors.
