<?php
class CommentModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;

        // Add the reply table to older installations automatically.
        $this->db->exec("CREATE TABLE IF NOT EXISTS comment_replies (
            reply_id INT AUTO_INCREMENT PRIMARY KEY,
            comment_id INT NOT NULL,
            admin_username VARCHAR(24) NOT NULL,
            reply VARCHAR(512) NOT NULL,
            date_posted DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci");
    }

    public function getLatestProduct() {
        $query = 'SELECT * FROM products ORDER BY product_id DESC LIMIT 1';
        $stmt = $this->db->query($query);

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function getCommentsForProduct($productId) {
        $query = 'SELECT c.*, r.reply_id, r.admin_username, r.reply, r.date_posted AS reply_date
                  FROM comments c
                  LEFT JOIN comment_replies r ON r.comment_id = c.comment_id
                  WHERE c.product_id = :product_id
                  ORDER BY c.comment_id ASC, r.reply_id ASC';
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addComment($productId, $userName, $commentText) {
        $query = 'INSERT INTO comments (product_id, user_name, comment, date_posted) VALUES (:product_id, :user_name, :comment, NOW())';
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':product_id', $productId, PDO::PARAM_INT);
        $stmt->bindParam(':user_name', $userName, PDO::PARAM_STR);
        $stmt->bindParam(':comment', $commentText, PDO::PARAM_STR);

        return $stmt->execute();
    }
    public function addAdminReply($commentId, $adminUsername, $replyText) {
        $stmt = $this->db->prepare(
            'INSERT INTO comment_replies (comment_id, admin_username, reply) VALUES (:comment_id, :admin_username, :reply)'
        );
        return $stmt->execute([
            ':comment_id' => $commentId,
            ':admin_username' => $adminUsername,
            ':reply' => $replyText
        ]);
    }

    public function commentExists($commentId) {
        $stmt = $this->db->prepare('SELECT comment_id FROM comments WHERE comment_id = :comment_id');
        $stmt->execute([':comment_id' => $commentId]);
        return (bool)$stmt->fetchColumn();
    }

}
?>
