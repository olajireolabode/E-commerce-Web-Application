<?php
class CartModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getAllProducts() {
        $query = "SELECT * FROM cart";
        $result = $this->db->query($query);
        return $result->fetchAll(PDO::FETCH_ASSOC);
    }

    public function add_to_cart($product_id, $quantity, $username) {
        $quantity = max(1, (int)$quantity);

        // Lock the product while checking stock so two checkout/cart requests
        // cannot accidentally oversell the same item.
        $this->db->beginTransaction();
        try {
            $stmt = $this->db->prepare(
                "SELECT product_quantity FROM products WHERE product_id = :product_id FOR UPDATE"
            );
            $stmt->execute([':product_id' => $product_id]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$product) {
                throw new RuntimeException('Product not found.');
            }

            $stmt = $this->db->prepare(
                "SELECT pk, quantity FROM cart WHERE product_id = :product_id AND username = :username LIMIT 1"
            );
            $stmt->execute([
                ':product_id' => $product_id,
                ':username' => $username
            ]);
            $existing = $stmt->fetch(PDO::FETCH_ASSOC);

            $newQuantity = $quantity + ($existing ? (int)$existing['quantity'] : 0);
            if ($newQuantity > (int)$product['product_quantity']) {
                throw new RuntimeException('Only ' . $product['product_quantity'] . ' item(s) are currently available.');
            }

            if ($existing) {
                $stmt = $this->db->prepare("UPDATE cart SET quantity = :quantity WHERE pk = :pk");
                $stmt->execute([
                    ':quantity' => $newQuantity,
                    ':pk' => $existing['pk']
                ]);
            } else {
                $stmt = $this->db->prepare(
                    "INSERT INTO cart(product_id, quantity, username) VALUES (:product_id, :quantity, :username)"
                );
                $stmt->execute([
                    ':product_id' => $product_id,
                    ':quantity' => $quantity,
                    ':username' => $username
                ]);
            }

            $this->db->commit();
            return ['success' => true, 'message' => 'Product added to cart.'];
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    public function deleteItemByID($itemid, $username = null) {
        $query = 'DELETE FROM cart WHERE pk = :pk';
        if ($username !== null) {
            $query .= ' AND username = :username';
        }
        $stmt = $this->db->prepare($query);
        $stmt->bindValue(':pk', $itemid, PDO::PARAM_INT);
        if ($username !== null) {
            $stmt->bindValue(':username', $username, PDO::PARAM_STR);
        }
        $stmt->execute();
    }

    public function updateItemByID($pk, $quantity, $username) {
        $quantity = (int)$quantity;

        if ($quantity <= 0) {
            $this->deleteItemByID($pk, $username);
            return ['success' => true, 'quantity' => 0];
        }

        $stmt = $this->db->prepare(
            "SELECT c.product_id, p.product_quantity
             FROM cart c
             JOIN products p ON p.product_id = c.product_id
             WHERE c.pk = :pk AND c.username = :username"
        );
        $stmt->execute([':pk' => $pk, ':username' => $username]);
        $item = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$item) {
            return ['success' => false, 'message' => 'Cart item not found.'];
        }

        if ($quantity > (int)$item['product_quantity']) {
            return [
                'success' => false,
                'message' => 'Only ' . $item['product_quantity'] . ' item(s) are available.',
                'quantity' => (int)$item['product_quantity']
            ];
        }

        $stmt = $this->db->prepare(
            "UPDATE cart SET quantity = :quantity WHERE pk = :pk AND username = :username"
        );
        $stmt->execute([
            ':quantity' => $quantity,
            ':pk' => $pk,
            ':username' => $username
        ]);

        return ['success' => true, 'quantity' => $quantity];
    }

    public function get_user_cart($username) {
        $query = "SELECT c.*, p.product_name, p.product_description, p.product_image,
                         p.product_price, p.product_quantity
                  FROM cart AS c
                  JOIN products AS p ON p.product_id = c.product_id
                  WHERE c.username = :username
                  ORDER BY c.pk";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Creates an order, records its products, reduces inventory, and empties
     * the user's cart as one atomic database transaction.
     */
    public function placeOrder($username) {
        $this->db->beginTransaction();

        try {
            $stmt = $this->db->prepare(
                "SELECT c.pk, c.product_id, c.quantity, p.product_name, p.product_price, p.product_quantity
                 FROM cart c
                 JOIN products p ON p.product_id = c.product_id
                 WHERE c.username = :username
                 ORDER BY c.pk
                 FOR UPDATE"
            );
            $stmt->execute([':username' => $username]);
            $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (!$items) {
                throw new RuntimeException('Your cart is empty.');
            }

            $total = 0.0;
            foreach ($items as $item) {
                if ((int)$item['quantity'] <= 0) {
                    throw new RuntimeException('Invalid quantity for ' . $item['product_name'] . '.');
                }
                if ((int)$item['quantity'] > (int)$item['product_quantity']) {
                    throw new RuntimeException(
                        $item['product_name'] . ' only has ' . $item['product_quantity'] . ' item(s) left in stock.'
                    );
                }
                $total += (float)$item['product_price'] * (int)$item['quantity'];
            }

            $stmt = $this->db->prepare("INSERT INTO orders (order_date) VALUES (CURDATE())");
            $stmt->execute();
            $orderId = (int)$this->db->lastInsertId();

            $orderItemStmt = $this->db->prepare(
                "INSERT INTO orders_products (order_id, orderitem_id, product_id, quantity)
                 VALUES (:order_id, :orderitem_id, :product_id, :quantity)"
            );
            $stockStmt = $this->db->prepare(
                "UPDATE products
                 SET product_quantity = product_quantity - :quantity
                 WHERE product_id = :product_id AND product_quantity >= :quantity"
            );

            foreach ($items as $index => $item) {
                $orderItemStmt->execute([
                    ':order_id' => $orderId,
                    ':orderitem_id' => $index + 1,
                    ':product_id' => $item['product_id'],
                    ':quantity' => $item['quantity']
                ]);

                $stockStmt->execute([
                    ':quantity' => $item['quantity'],
                    ':product_id' => $item['product_id']
                ]);

                if ($stockStmt->rowCount() !== 1) {
                    throw new RuntimeException('Inventory changed while placing the order. Please try again.');
                }
            }

            $stmt = $this->db->prepare(
                "INSERT INTO users_orders (user_name, order_id) VALUES (:username, :order_id)"
            );
            $stmt->execute([
                ':username' => $username,
                ':order_id' => $orderId
            ]);

            $stmt = $this->db->prepare("DELETE FROM cart WHERE username = :username");
            $stmt->execute([':username' => $username]);

            $this->db->commit();

            return [
                'success' => true,
                'order_id' => $orderId,
                'total' => $total,
                'items' => $items
            ];
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }
}
